h1 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]) ;

bsSTFTth95 = STFTbsTHdense(:,:,2) ;

MM = quantile([abs(tfrXth(:)); abs(bsSTFTth95(:))], .99) ;
subplot_tight(2, 3, 1, [0.035 0.03]) ;
imagesc(time, tfrticX*Hz, abs(tfrX), [0 MM]) ; axis xy
colorbar ; ylabel('Freq (Hz)')
set(gca, 'fontsize', 16) ; colormap(1-gray)
text(0.5, 47,'(a)','fontsize', 24) ;

subplot_tight(2, 3, 2, [0.035 0.03]) ;
imagesc(time, tfrticX*Hz, abs(bsSTFTth95), [0 MM]) ; axis xy
colorbar ;  
set(gca, 'fontsize', 16) ; colormap(1-gray)
text(0.5, 47,'(b)','fontsize', 24) ;

subplot_tight(2, 3, 3, [0.035 0.03]) ;
imagesc(time, tfrticX*Hz, abs(tfrXth), [0 MM]) ; axis xy
colorbar ;  
set(gca, 'fontsize', 16) ; colormap(1-gray)
text(0.5, 47,'(c)','fontsize', 24) ;




bsSSTth95 = SSTbsTHdense(:,:,2) ;
MM = quantile([abs(tfrsqXth(:)); abs(bsSSTth95(:))], .99) ;
subplot_tight(2, 3, 4, [0.035 0.03]) ;
imagesc(time, tfrticX*Hz, abs(tfrsqX), [0 MM]) ; axis xy
colorbar ; xlabel('Time (s)') ; ylabel('Freq (Hz)')
set(gca, 'fontsize', 16) ; colormap(1-gray)
text(0.5, 47,'(d)','fontsize', 24) ;

subplot_tight(2, 3, 5, [0.035 0.03]) ;
imagesc(time, tfrticX*Hz, abs(bsSSTth95), [0 MM]) ; axis xy
colorbar ; xlabel('Time (s)') ; 
set(gca, 'fontsize', 16) ; colormap(1-gray)
text(0.5, 47,'(e)','fontsize', 24) ;

subplot_tight(2, 3, 6, [0.035 0.03]) ;
imagesc(time, tfrticX*Hz, abs(tfrsqXth), [0 MM]) ; axis xy
colorbar ; xlabel('Time (s)') ;
set(gca, 'fontsize', 16) ; colormap(1-gray)
text(0.5, 47,'(f)','fontsize', 24) ;

if SAVEFIG
    exportgraphics(h1, 'Figure3AHM2ThreTFR.pdf', 'ContentType', 'vector', 'BackgroundColor','none');
    close
end