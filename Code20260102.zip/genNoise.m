function [LSnoise, truephi, tvsigma] = genNoise(N, BSP) 

% generate noise

% this is the order of tvAR
trueb = 2 ;

% generate locally stationary
truephi = zeros(trueb, N) ;
truephi(1,:) = -0.5 * (0.7+0.3*cos(2*pi*(1:N)/N)) ;
truephi(2,:) = 0.3 * sqrt(0.1+(1:N)/N/4) ;
tvsigma = 4 * (1+0.5*cos(2*4*(1:N)'/N+2)) ;

if 0
    truephi(1,980:end) = 0.5 * (0.6+0.2*cos(2*pi*(980:N)/N)) ;
    truephi(2,980:end) = -0.3 * sqrt(0.2+(980:N)/N/4) ;
    tvsigma(980:end) = 2.2 - tvsigma(980:end) ;
end

[LSnoise] = gentvAR(truephi, tvsigma, BSP) ;