clear ; close all ; clc
addpath('/Users/hautiengwu/Dropbox/___course/2023 NCKU lecture/Matlab code/tool') ;
addpath('/Users/hautiengwu/Dropbox/___course/2023 NCKU lecture/Matlab code/SST') ;
addpath('./esttvAR') ;

% load MFEToolbox before running this
addpath('/Users/hautiengwu/Dropbox/___course/2023 NCKU lecture/Matlab code/MFEToolbox/timeseries') ;

%folder = '/Users/hautiengwu/Dropbox/___course/2023 NCKU lecture/Matlab code/database/' ;
scrsz = get(0,'ScreenSize') ;

dbstop if error



% the simulated signal is null or nonnull (2 IMT function)
NONNULLsignal = 1 ;

% if we want to get BS threshold under null
genFIGURE = 0 ;

% save generated figures
SAVEFIG = 0 ;

% carry out power analysis (under nonnull)
POWERanalysis = 0 ;

% generate full TFR (for comparison of distribution)
genFULL = 1 ;



% the sampling rate for the simulated signal
Hz = 100 ;
% the number of sampling points of the simulated signal
N = 2^11 ;
% the sampling time of the simulated signal
time = (1:1:N)'/Hz ;

% fix the random seed for the reproducibility issue (this is set for the
% figure generation)



BSP.b = 2 ;     % guessed AR order (use the truth)
BSP.m = 16 ;    % number of o.n. basis
BSP.BSno = 1000 ; % number of BS ; (5000 needs 2412 s)
BSP.fHOP = 20 ; % hop for frequency domain
BSP.noisetype = 'Gaussian' ;
BSP.type = 'HK2017' ; % 'Poskitt2025' ; %'KP2015' ; %'DZ2022' ; %'LSV2025' ; % 

PP.NoWindowsInConceFT = 1 ;
PP.NoConceFT = 1 ;
PP.WindowLength = 477 ; %Hz*4 + 1 ;
PP.WindowBandwidth = 6 ;
PP.SamplingRate = Hz ;
PP.HighFrequencyLimit = 0.5 ;
PP.LowFrequencyLimit = 0 ;
PP.FrequencyAxisResolution = 4e-4 ;
PP.HOP = 25 ;


% carry out rejection rate
Alist = linspace(0, 2, 9) ; %1.5, 7) ;

% number of Monte Carlo
MCNo = 100 ;


% ERR is the error of IF estimateion
ERRSTFT = zeros(length(Alist), 4, MCNo) ;
ERRSST = zeros(length(Alist), 4, MCNo) ;

% This is the rejection rate
DETECTSTFT = zeros(length(Alist), 1) ;
DETECTSST = zeros(length(Alist), 1) ;


ETime = zeros(MCNo, length(Alist)) ;

% to generate figures for the paper, set MCNo=1 and Alist=[1] ;

for MCidx = 1:MCNo
for Aidx = 1:length(Alist)

fprintf(['*** Run ' num2str(MCidx) ' ' num2str(Aidx) '\n'])



% LSnoise is true noise
% s1 is true signal
% xm is noisy signal
% x is estimated noise (in the null case, simply set x = xm)

s1 = zeros(N, 1) ;
s1hat = zeros(N, 1) ;
s2 = zeros(N, 1) ;
s2hat = zeros(N, 1) ;
if1 = zeros(N, 1) ;
if2 = zeros(N, 1) ;
phi1 = zeros(N, 1) ;
phi2 = zeros(N, 1) ;
am1 = zeros(N, 1) ;
am2 = zeros(N, 1) ;


initstate(100 + (MCidx-1)*MCNo + Aidx) ;

% BSPtrue is used to generate real model signals
BSPtrue = BSP ;
BSPtrue.noisehat = random('T', 10, 100, 1) ;
BSPtrue.noisetype = 'T10' ;
BSPtrue.MODEL = 1 ;

[LSnoise, truephi, tvsigma] = genNoise(N, BSPtrue) ;

BSPtrue.phihat = truephi ; 
BSPtrue.sigmai = tvsigma ;



% xm: noisy signal; xhat: clean signal; x: estimated noise
xm = LSnoise ;
noisehat = LSnoise ;
xhat = zeros(N, 1) ;



% generate simulated signal & reconstruct signal when nonnull

if NONNULLsignal % non-null case (include the reconstruction step)

    fprintf('Generate non-null signal\n')

    initstate(9999 + (MCidx-1)*MCNo + Aidx) ;
    genSignal ;

    % if space permits, save results to save time.
    %if ~exist(['BS/00BS_' num2str(Aidx) '_' num2str(MCidx) '.mat'], 'file')
        genReconstruction ;
    %    save(['BS/00BS_' num2str(Aidx) '_' num2str(MCidx) '.mat'],...
    %        'tfrX', 'tfrticX', 'tfrsqX', 'c1', 'c2', 'recon1', 'recon2') ;
    %else
    %    load(['BS/00BS_' num2str(Aidx) '_' num2str(MCidx) '.mat']) ;
    %    tfrsqticX = tfrticX ;
    %    s1hat = real(recon1)' ;
    %    s2hat = real(recon2)' ;
    %    xhat = s1hat + s2hat ;
    %    noisehat = xm - xhat ;        
    %end
    
        % plot results -- this is Figure 1
        if 0 && MCidx == 1 && Alist(Aidx) == 1 ; genFigure1 ; end

else

    [tfrX, tfrticX, tfrsqX, ~, tfrsqticX, ~] = ConceFT_sqSTFT_C(xm, ...
        PP.LowFrequencyLimit, PP.HighFrequencyLimit, PP.FrequencyAxisResolution, ...
        1, PP.WindowLength, PP.NoWindowsInConceFT, PP.WindowBandwidth, PP.NoConceFT, 1, 0) ;
end



%% tvAR approximation of the noise
fprintf('Apply tvAR to approximate noise\n')
[phihat, sigmaihat] = esttvAR(noisehat, BSP) ;

% plot an example of BS noise. This is Figure 2
if 0 && MCidx == 1 && Alist(Aidx) == 1 
    [bsnoise] = gentvAR(phihat, sigmaihat, BSP) ;
    genFigure2 ; 
end




%% generate NULL distribution by BS

% downsample size to save space.
% HOP is time. Also downsample frequency by fHOP
idxf = BSP.fHOP/2: BSP.fHOP: length(tfrticX)-BSP.fHOP/2 ;
idxt = 5: PP.HOP: N ;

% BSP is used to generate bootstrapped signal
BSP.Fn = length(tfrticX) ;
BSP.Tn = N ;
BSP.downFn = length(idxf) ;
BSP.downTn = length(idxt) ;
BSP.noisehat = noisehat ;
BSP.phihat = phihat ; 
BSP.sigmai = sigmaihat ;
BSP.MODEL = 0 ;

BSPtrue.Fn = length(tfrticX) ;
BSPtrue.Tn = N ;
BSPtrue.downFn = length(idxf) ;
BSPtrue.downTn = length(idxt) ;


% generate these percentiles as threshold
THlist = [0.025 0.95 0.975 0.99] ;


% these statistics only exist when genFULL=1
STFTSCR = zeros(BSP.BSno, 1) ;
SSTSCR = zeros(BSP.BSno, 1) ;


if genFULL

    % generate BS null distribution (input signal is zero)

    if ~exist(['BS/BS_' num2str(Aidx) '_' num2str(MCidx) '.mat'], 'file')
        
        initstate(9877777 + (MCidx-1)*MCNo + Aidx) ;
        fprintf(['Generate BS ... use ' BSP.type '\n'])

        BSP.xhat = zeros(size(noisehat)) ;

        % percentiles in STFTbsTH, bsSSTth are estimated using the full TFR.
        % STFTbs, SSTbs are full in the frequency axis but sparse in the time
        % domain

        ttt = tic ;
        [STFTbs, SSTbs, STFTbsTH, SSTbsTH] = genBSdistribution...
            (PP, BSP, THlist, genFULL) ;
        ETime(MCidx, Aidx) = toc(ttt) ;
        
        for kk = 1: BSP.BSno
            tmp = squeeze(abs(STFTbs(:, :, kk))) ;
            STFTSCR(kk) = max(tmp(:)) ;
            tmp = squeeze(abs(SSTbs(:, :, kk))) ;
            SSTSCR(kk) = max(tmp(:)) ;
        end
        
        save((['BS/BS_' num2str(Aidx) '_' num2str(MCidx) '.mat']),...
            'STFTSCR', 'SSTSCR', 'STFTbsTH', 'SSTbsTH', 'noisehat', 'xhat') ;

    else
        
        initstate(9877777 + (MCidx-1)*MCNo + Aidx) ;
        fprintf('Load BS ...\n')
        noisehat0 = noisehat ; xhat0 = xhat ;
        load(['BS/BS_' num2str(Aidx) '_' num2str(MCidx) '.mat'])
        disp([mean(abs(noisehat-noisehat0)) mean(abs(xhat-xhat0))]) ; clear x0 xhat0

    end

    % plot QQplot of null dist of BS against true -- Figure S4 and Figure S5
    if genFIGURE && MCidx == 1 && Alist(Aidx) == 1  

        fprintf('Generate true model distribution ...\n')
        
        BSPtrue.xhat = zeros(size(noisehat)) ;

        % generate REAL null distribution
        initstate(pi^10 + (MCidx-1)*MCNo + Aidx) ;
        [STFTreal, SSTreal, STFTrealTH, SSTrealTH] = genBSdistribution...
            (zeros(size(noisehat)), PP, BSPtrue, THlist, genFULL) ;

        genFigureS4S5 ; 

        [STFTrealTHdense, SSTrealTHdense] = genBSTHDense(STFTrealTH, SSTrealTH, PP, BSP) ;

    end

else

    % STFTbsTH, SSTbsTH are percentiles estimated using P2. 
    % This approach helps increase the
    % number of BS by saving memory. Runtime is the same.
    % STFTbs, SSTbs are empty matrices. 
    initstate(9877777 + (MCidx-1)*MCNo + Aidx) ;
    [STFTbs, SSTbs, STFTbsTH, SSTbsTH] = genBSdistribution...
        (zeros(size(noisehat)), PP, BSP, THlist, 0) ;

end


% extend the threshold to the dense TFR grids via simple interpolation
[STFTbsTHdense, SSTbsTHdense] = genBSTHDense(STFTbsTH, SSTbsTH, PP, BSP) ;



%% Detection using SCR (need full version)
if genFULL
    
    fprintf('Run detection mission using SCR\n')
    tmp = abs(tfrX(idxf, idxt)) ;
    if max(tmp(:)) > quantile(STFTSCR, .95)
        DETECTSTFT(Aidx) = DETECTSTFT(Aidx) + 1 ;
    end

    Q = [max(tmp(:))  quantile(STFTSCR, .95)] ;

    tmp = abs(tfrsqX(idxf, idxt)) ;
    if max(tmp(:)) > quantile(SSTSCR, .95)
        DETECTSST(Aidx) = DETECTSST(Aidx) + 1 ;
    end

    Q = [Q max(tmp(:))  quantile(SSTSCR, .95)] ;

    disp(Q)
    %fprintf(['Detection rate: STFT = ' num2str(DETECTSTFT(Aidx)/MCNo) ...
    %    ', SST = ' num2str(DETECTSST(Aidx)/MCNo) '\n'])
end

if MCidx == MCNo && Aidx == length(Alist)
    h1 = figure ;
    hold off ; plot(Alist, 100*DETECTSST/MCidx, 'k--', 'linewidth', 2) ; hold on ; 
    plot(Alist, 100*DETECTSTFT/MCidx, 'r', 'linewidth', 2) ; 
    plot(Alist, 100*DETECTSST/MCidx, 'ko', 'linewidth', 2) ;  
    plot(Alist, 100*DETECTSTFT/MCidx, 'ro', 'linewidth', 2) ; 
    %title([num2str(Aidx) ' ' num2str(MCidx)]) ;
    set(gca,'fontsize', 24) ; grid on ; grid minor
    legend('SST-SCR', 'STFT-SCR') ;
    xlabel('a') ; ylabel('Rejection rate (%)') ;
    exportgraphics(h1, 'RejectionRate.pdf', 'ContentType', 'vector', 'BackgroundColor','none');
    pause
end



%% Estimate IF
if genFULL

    fprintf('Estimate IF\n')
    c1 = round(if1 ./ (tfrsqticX(2)-tfrsqticX(1)) / Hz) ;
    c2 = round(if2 ./ (tfrsqticX(2)-tfrsqticX(1)) / Hz) ;
    midc = round((c1+c2)/2) ;

    c1hatSTFT = nan(size(c1)) ;
    c2hatSTFT = nan(size(c1)) ;
    c1hatSST = nan(size(c1)) ;
    c2hatSST = nan(size(c1)) ;
    
    % 99 percentile
    for jj = 1: length(c1hatSTFT)
        idx = find(abs(tfrX(1:midc(jj), jj))>squeeze(STFTbsTHdense(1:midc(jj),jj,2))) ;
        if ~isempty(idx)
            [~, tmp2] = max( abs(tfrX(idx, jj)) ) ;
            c1hatSTFT(jj) = idx(tmp2(1));
        end

        idx = find(abs(tfrX(midc(jj)+1:end, jj))>squeeze(STFTbsTHdense(midc(jj)+1:end,jj,2))) ;
        if ~isempty(idx)
            [~, tmp2] = max( abs(tfrX(midc(jj)+idx, jj)) ) ;
            c2hatSTFT(jj) = midc(jj) + idx(tmp2(1));
        end
   
        idx = find(abs(tfrsqX(1:midc(jj), jj))>squeeze(SSTbsTHdense(1:midc(jj),jj,2))) ;
        if ~isempty(idx)
            [~, tmp2] = max( abs(tfrsqX(idx, jj)) ) ;
            c1hatSST(jj) = idx(tmp2(1));
        end

        idx = find(abs(tfrsqX(midc(jj)+1:end, jj))>squeeze(SSTbsTHdense(midc(jj)+1:end, jj, 2))) ;
        if ~isempty(idx)
            [~, tmp2] = max( abs(tfrsqX(midc(jj)+idx, jj)) ) ;
            c2hatSST(jj) = midc(jj) + idx(tmp2(1));
        end
    end

    ERR1STFT = (c1hatSTFT - c1) * (tfrticX(2)-tfrticX(1)) * Hz ;
    ERR2STFT = (c2hatSTFT - c2) * (tfrticX(2)-tfrticX(1)) * Hz ;
    ERR1SST = (c1hatSST - c1) * (tfrsqticX(2)-tfrsqticX(1)) * Hz ;
    ERR2SST = (c2hatSST - c2) * (tfrsqticX(2)-tfrsqticX(1)) * Hz ;

end

idx = idxt(idxt > Hz & idxt < N-Hz) ;
ERRSTFT(Aidx, :, MCidx) = [mean(ERR1STFT(idx)) std(ERR1STFT(idx)) mean(ERR2STFT(idx)) std(ERR2STFT(idx))]' ;
ERRSST(Aidx, :, MCidx) = [mean(ERR1SST(idx)) std(ERR1SST(idx)) mean(ERR2SST(idx)) std(ERR2SST(idx))]' ;

%disp([mean(ERR1STFT(idx)) std(ERR1STFT(idx)) mean(ERR2STFT(idx)) std(ERR2STFT(idx))]) ;
%disp([mean(ERR1SST(idx)) std(ERR1SST(idx)) mean(ERR2SST(idx)) std(ERR2SST(idx))]) ;






%% Plot STFT/SST threshold -- generate Figure 3


if genFIGURE && MCidx == 1 && Alist(Aidx) == 1  
    
    fprintf('generate thresholded figures \n')
    % apply the threhold to get the thresholded TFR (use .99 percentile as the threshold)
    tfrXth = (abs(tfrX)>squeeze(STFTbsTHdense(:,:,4))) .* tfrX ;
    tfrsqXth = (abs(tfrsqX)>squeeze(SSTbsTHdense(:,:,4))) .* tfrsqX ;

    tfrXthreal = (abs(tfrX)>squeeze(STFTrealTHdense(:,:,4))) .* tfrX ;
    tfrsqXthreal = (abs(tfrsqX)>squeeze(SSTrealTHdense(:,:,4))) .* tfrsqX ;

    if strcmp(BSP.type, 'DZ2022') 
        % this is for the main article
        genFigure3 ; 
    else
        % this is for the supplementary
        genFigureS8 ;
    end

end







%% generate NONNULL distribution and CI by BS
if 0 && MCidx == 1 && Alist(Aidx) == 1 

    fprintf('Generate nonnull distribution via BS\n')
    genFULL = 1 ;
    
    BSP.xhat = xhat ;

    % generate BS null distribution
    BSP.Ntype = 'Gaussian' ;
    [STFTbs2, SSTbs2, STFTbsTH2, bsSSTth2] = genBSdistribution...
        (PP, BSP, THlist, genFULL) ;
    
    
    
    % plot CI plot -- generate Figure 3
    if genFIGURE ; genFigure4 ; end
    
    % plot QQplot of null dist of BS against true for STFT&SST -- Figure S4
    % and Figure S5

    BSPtrue.xhat = s1+s2 ;

    if genFIGURE
        % generate REAL null distribution
        [STFTreal2, SSTreal2, realSTFTth2, realSSTth2] = genBSdistribution...
            (PP, BSPtrue, THlist, genFULL) ;
    
        genFigureS6S7 ; 
    end

end



% to save some space
clear STFTbs SSTbs
pause(1)

end % end of MC list
end % end of A list