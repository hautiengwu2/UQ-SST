h1 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]) ;

for qqq = 1:12
    for rrr = 1:16
        subplot(12,16,(qqq-1)*16+rrr) ;
        T = imag(squeeze(STFTreal2(qqq*5, rrr*5, :))) ;
        B = imag(squeeze(STFTbs2(qqq*5, rrr*5, :))) ;
        MM = max([max(T) max(B)]) ;
        mm = min([min(T) min(B)]) ;
        qqplot(T, B) ; axis tight ; axis([mm MM mm MM]) ;
        xlabel('') ; ylabel('')
        if rrr == 1 ; ylabel(round(100*tfrsqticX(idxf(qqq*5)))/100) ; end
        if qqq == 12 ; xlabel(idxt(rrr*5)) ; end
    end
end


if SAVEFIG
    exportgraphics(h1, 'FigureS6AHM2STFTQQ.pdf', 'ContentType', 'vector', 'BackgroundColor','none');
    close
end



% plot SST QQplot
h1 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]) ;

for qqq = 1:12
    for rrr = 1:16
        subplot(12,16,(qqq-1)*16+rrr) ;
        T = real(squeeze(SSTreal2(qqq*5, rrr*5, :))) ;
        B = real(squeeze(SSTbs2(qqq*5, rrr*5, :))) ;
        MM = max([max(T) max(B)]) ;
        mm = min([min(T) min(B)]) ;
        qqplot(T, B) ; axis tight ; axis([mm MM mm MM]) ;
        xlabel('') ; ylabel('')
        if rrr == 1 ; ylabel(round(100*tfrsqticX(idxf(qqq*5)))/100) ; end
        if qqq == 12 ; xlabel(idxt(rrr*5)) ; end
    end
end

if SAVEFIG
    exportgraphics(h1, 'FigureS7AHM2SSTQQ.pdf', 'ContentType', 'vector', 'BackgroundColor','none');
    close
end