h1 = figure('Position',[1 scrsz(4) scrsz(3)*3/4 scrsz(4)*3/4]) ;

subplot_tight(4, 1, 1, [0.042 0.05])
for jj = 1: BSP.b
    plot(truephi(jj,:), 'color', [.7 .7 .7], 'linewidth', 2) ; hold on ;
    plot(phihat(jj,:), 'k', 'linewidth', 2)
end
legend('$\phi_{i,1}$','$\hat{\phi}_{i,1}$','$\phi_{i,2}$','$\hat{\phi}_{i,2}$',...
    'interpreter', 'latex')
text(10, 0.1,'(a)','fontsize', 24) ;
axis tight ; set(gca, 'fontsize', 16) ; set(gca,'xlabel', []) ;

subplot_tight(4, 1, 2, [0.042 0.05])
plot(x, 'k') ; axis tight ; set(gca, 'fontsize', 16) ; set(gca,'xlabel', []) ;
text(10, 18,'(b)','fontsize', 24) ;
ylabel('$x_i$', 'interpreter', 'latex')

subplot_tight(4, 1, 3, [0.042 0.05])
plot(bsnoise, 'k') ; axis tight ; set(gca, 'fontsize', 16)
text(0.5, 20,'(c)','fontsize', 24) ;
xlabel('index $i$', 'interpreter', 'latex') ; ylabel('$\hat{x}_i$', 'interpreter', 'latex')

if SAVEFIG
    exportgraphics(h1, 'Figure2AHM2BSnoise.pdf', 'ContentType', 'vector', 'BackgroundColor','none');
    close
end