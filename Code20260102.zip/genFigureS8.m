h1 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]) ;

bsSTFTth95 = STFTbsTHdense(:,:,2) ;
realSTFTth95 = STFTrealTHdense(:,:,2) ;

MM = quantile([abs(tfrXth(:)); abs(bsSTFTth95(:)); abs(realSTFTth95(:))], .99) ;
subplot_tight(3, 4, 1, [0.035 0.03]) ;
imagesc(time, tfrticX*Hz, abs(tfrX), [0 MM]) ; axis xy
colorbar ; ylabel('Freq (Hz)')
set(gca, 'fontsize', 16) ; colormap(1-gray)
text(0.5, 47,'(a)','fontsize', 24) ;

subplot_tight(3, 4, 5, [0.035 0.03]) ;
imagesc(time, tfrticX*Hz, abs(realSTFTth95), [0 MM]) ; axis xy
colorbar ; ylabel('Freq (Hz)')
set(gca, 'fontsize', 16) ; colormap(1-gray)
text(0.5, 47,'(b)','fontsize', 24) ;

subplot_tight(3, 4, 9, [0.035 0.03]) ;
imagesc(time, tfrticX*Hz, abs(tfrXthreal), [0 MM]) ; axis xy
colorbar ; ylabel('Freq (Hz)') ; xlabel('Time (s)') ;
set(gca, 'fontsize', 16) ; colormap(1-gray)
text(0.5, 47,'(c)','fontsize', 24) ;

subplot_tight(3, 4, 6, [0.035 0.03]) ;
imagesc(time, tfrticX*Hz, abs(bsSTFTth95), [0 MM]) ; axis xy
colorbar ; 
set(gca, 'fontsize', 16) ; colormap(1-gray)
text(0.5, 47,'(d)','fontsize', 24) ;

subplot_tight(3, 4, 10, [0.035 0.03]) ;
imagesc(time, tfrticX*Hz, abs(tfrXth), [0 MM]) ; axis xy
colorbar ;  xlabel('Time (s)') ;
set(gca, 'fontsize', 16) ; colormap(1-gray)
text(0.5, 47,'(e)','fontsize', 24) ;




bsSSTth95 = SSTbsTHdense(:,:,2) ;
realSSTth95 = SSTrealTHdense(:,:,2) ;
MM = quantile([abs(tfrsqXth(:)); abs(bsSSTth95(:)); abs(realSSTth95(:))], .99) ;
subplot_tight(3, 4, 3, [0.035 0.03]) ;
imagesc(time, tfrticX*Hz, abs(tfrsqX), [0 MM]) ; axis xy
colorbar ; xlabel('Time (s)') ; 
set(gca, 'fontsize', 16) ; colormap(1-gray)
text(0.5, 47,'(f)','fontsize', 24) ;

subplot_tight(3, 4, 7, [0.035 0.03]) ;
imagesc(time, tfrticX*Hz, abs(realSSTth95), [0 MM]) ; axis xy
colorbar ; xlabel('Time (s)') ; %ylabel('Freq (Hz)')
set(gca, 'fontsize', 16) ; colormap(1-gray)
text(0.5, 47,'(g)','fontsize', 24) ;

subplot_tight(3, 4, 11, [0.035 0.03]) ;
imagesc(time, tfrticX*Hz, abs(tfrsqXthreal), [0 MM]) ; axis xy
colorbar ; xlabel('Time (s)') ;
set(gca, 'fontsize', 16) ; colormap(1-gray)
text(0.5, 47,'(h)','fontsize', 24) ;

subplot_tight(3, 4, 8, [0.035 0.03]) ;
imagesc(time, tfrticX*Hz, abs(bsSSTth95), [0 MM]) ; axis xy
colorbar ; xlabel('Time (s)') ; %ylabel('Freq (Hz)')
set(gca, 'fontsize', 16) ; colormap(1-gray)
text(0.5, 47,'(i)','fontsize', 24) ;

subplot_tight(3, 4, 12, [0.035 0.03]) ;
imagesc(time, tfrticX*Hz, abs(tfrsqXth), [0 MM]) ; axis xy
colorbar ; xlabel('Time (s)') ;
set(gca, 'fontsize', 16) ; colormap(1-gray)
text(0.5, 47,'(j)','fontsize', 24) ;

if SAVEFIG
    exportgraphics(h1, 'Figure3AHM2ThreTFR.pdf', 'ContentType', 'vector', 'BackgroundColor','none');
    close
end