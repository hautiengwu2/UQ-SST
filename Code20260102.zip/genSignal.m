% generate signal

am1 = smooth(cumsum(randn(N,1)) ./ Hz, 900, 'loess') ;
am1 = 3 + am1 ./ max(abs(am1)) ;

% the instantaneous frequency of the simulated signal
if1 = smooth(cumsum(randn(N,1)) ./ Hz, 800, 'loess') ;
if1 = 6 + 3.2 * if1 ./ max(abs(if1)) + 4*(time/17) ;
phi1 = cumsum(if1) / Hz ;

% the simulated signal.
s1 = am1 .* cos(2*pi*phi1) ;


am2 = smooth(cumsum(randn(N,1)) ./ Hz, 700, 'loess') ;
am2 = 3 + am2 ./ max(abs(am2)) + time/time(end) ;

% the instantaneous frequency of the simulated signal
while 1
    if2 = smooth(cumsum(randn(N,1)) ./ Hz, 900, 'loess') ;
    if2 = 27 + 9*if2 ./ max(abs(if2)) - 4*(time/17) ;
    % avoid frequency separation
    if min(if2 - if1) > 2 
        break
    end
end

phi2 = cumsum(if2) / Hz ;

% the simulated signal.
s2 = am2 .* cos(2*pi*phi2) ;



xm = Alist(Aidx)*(s1 + s2) + LSnoise ;
