classdef P2 < handle
%P2  Streaming quantile estimation via the P² (P-squared) algorithm.
%     Supports tracking multiple quantiles simultaneously in O(1) memory.
%
% Usage:
%   p = P2([0.1 0.5 0.9]);  % track 10th, 50th, 90th
%   p.add(3.14);            % add samples one-by-one
%   q50 = p.result(0.5);    % query any quantile
%   allq = p.resultAll();   % returns current estimates for the tracked set
%
% This is a MATLAB translation of the provided C++ template implementation.

    properties (SetAccess = private)
        quantiles           % row vector of tracked quantiles (length m)
        nQuantiles          % m
        nMarkers            % 2 + 3*m
        count = 0           % # of samples seen so far

        positions           % 1..nMarkers (double)
        heights             % marker heights (double)
        increments          % dn' per marker (double)
        desiredPositions    % n' (double)

        % buffer for first nMarkers samples (before algorithm start)
        buf
    end

    methods
        function obj = P2(qs)
            % Constructor.
            % qs: scalar or vector of quantiles in (0,1). If omitted, defaults to 0.5.
            if nargin < 1 || isempty(qs)
                qs = 0.5;
            end
            qs = qs(:).';
            assert(all(qs > 0 & qs < 1), 'Quantiles must be in (0,1).');

            obj.quantiles  = qs;
            obj.nQuantiles = numel(qs);
            obj.nMarkers   = 2 + 3*obj.nQuantiles;

            % Allocate arrays
            obj.positions        = zeros(1, obj.nMarkers);
            obj.heights          = zeros(1, obj.nMarkers);
            obj.increments       = zeros(1, obj.nMarkers);
            obj.desiredPositions = zeros(1, obj.nMarkers);

            % increments: first two fixed as in C++ version
            obj.increments(1) = 0.0;
            obj.increments(2) = 1.0;

            % Fill per-quantile triplets [q, q/2, (1+q)/2]
            for k = 1:obj.nQuantiles
                base = 2 + (k-1)*3;
                q = obj.quantiles(k);
                obj.increments(base+0) = q;
                obj.increments(base+1) = q/2;
                obj.increments(base+2) = (1+q)/2;
            end

            % Sort increments and compute initial desired positions n' = (m-1)*inc + 1
            obj.increments       = sort(obj.increments, 'ascend');
            obj.desiredPositions = (obj.nMarkers - 1) * obj.increments + 1;

            % buffer until we have nMarkers samples
            obj.buf = zeros(1, obj.nMarkers);
        end

        function add(obj, x)
            % Add one new observation.
            if obj.count < obj.nMarkers
                obj.count = obj.count + 1;
                obj.buf(obj.count) = x;
                if obj.count == obj.nMarkers
                    obj.initializeAlgorithm();
                end
                return;
            end
            obj.runAlgorithm(x);
        end

        function y = result(obj, q)
            % Return the estimate for quantile q in (0,1).
            if nargin < 2
                % if user didn't specify, use the first tracked quantile
                q = obj.quantiles(1);
            end
            assert(q > 0 && q < 1, 'q must be in (0,1)');

            if obj.count < obj.nMarkers
                % Not enough samples: return order statistic closest to q
                h = sort(obj.buf(1:obj.count), 'ascend');
                % find index i minimizing |i/count - q|
                idx = 1;
                best = abs(1/obj.count - q);
                for i = 2:obj.count
                    err = abs(i/obj.count - q);
                    if err < best
                        best = err; idx = i;
                    end
                end
                y = h(idx);
            else
                % After initialization: pick the marker whose increment is nearest to q
                [~, idx] = min(abs(obj.increments - q));
                y = obj.heights(idx);
            end
        end

        function v = resultAll(obj)
            % Return estimates for the tracked set (in the order of obj.quantiles).
            v = zeros(size(obj.quantiles));
            for k = 1:numel(obj.quantiles)
                v(k) = obj.result(obj.quantiles(k));
            end
        end
    end

    methods (Access = private)
        function initializeAlgorithm(obj)
            % Sort initial heights and initialize positions 1..nMarkers
            obj.heights   = sort(obj.buf(1:obj.nMarkers), 'ascend');
            obj.positions = 1:obj.nMarkers;
            % Keep desiredPositions as set in constructor
        end

        function runAlgorithm(obj, x)
            % ------- Step B.1: find cell index and update endpoints -------
            n = obj.nMarkers;
            if x < obj.heights(1)
                obj.heights(1) = x;
                k = 2;  % increment markers 2..n
            elseif x >= obj.heights(n)
                obj.heights(n) = x;
                k = n;  % increment only last marker
            else
                % smallest i with x < heights(i)
                k = find(x < obj.heights, 1, 'first');
                % k is in 2..n-1; matches C++ logic
            end

            % ------- Step B.2: advance positions and desired positions -------
            obj.positions(k:end) = obj.positions(k:end) + 1;
            % desired positions always advance by increments at every step
            obj.desiredPositions = obj.desiredPositions + obj.increments;

            % ------- Step B.3: adjust interior markers with parabolic / linear -------
            for i = 2:(n-1)
                d = obj.desiredPositions(i) - obj.positions(i);
                if (d >= 1 && obj.positions(i+1) - obj.positions(i) > 1) || ...
                   (d <= -1 && obj.positions(i-1) - obj.positions(i) < -1)

                    s = sign(d);  % +1 or -1

                    hp = obj.parabolic(i, s); % proposed via quadratic
                    if obj.heights(i-1) < hp && hp < obj.heights(i+1)
                        obj.heights(i) = hp;
                    else
                        obj.heights(i) = obj.linear(i, s);
                    end
                    obj.positions(i) = obj.positions(i) + s;
                end
            end
        end

        function y = parabolic(obj, i, d)
            % Quadratic interpolation step (Jain–Chlamtac 1985)
            num = (obj.positions(i)   - obj.positions(i-1) + d) * ...
                    (obj.heights(i+1) - obj.heights(i))   / max(1, (obj.positions(i+1) - obj.positions(i))) + ...
                  (obj.positions(i+1) - obj.positions(i) - d) * ...
                    (obj.heights(i)   - obj.heights(i-1)) / max(1, (obj.positions(i)   - obj.positions(i-1)));
            den = (obj.positions(i+1) - obj.positions(i-1));
            if den == 0
                % extremely degenerate; fall back to linear
                y = obj.linear(i, d);
            else
                y = obj.heights(i) + d * (num / den);
            end
        end

        function y = linear(obj, i, d)
            % Linear fallback step.
            den = obj.positions(i + d) - obj.positions(i);
            if den == 0
                y = (obj.heights(i + d) + obj.heights(i)) / 2;
            else
                y = obj.heights(i) + d * (obj.heights(i + d) - obj.heights(i)) / den;
            end
        end
    end
end
