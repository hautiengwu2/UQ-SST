clear ; close all ; clc
addpath('/Users/hautiengwu/Dropbox/___course/2023 NCKU lecture/Matlab code/tool') ;
addpath('/Users/hautiengwu/Dropbox/___course/2023 NCKU lecture/Matlab code/SST') ;

% load MFEToolbox before running this
addpath('/Users/hautiengwu/Dropbox/___course/2023 NCKU lecture/Matlab code/MFEToolbox/timeseries') ;
addpath('./esttvAR') ;

folder = '/Users/hautiengwu/Dropbox/___course/2023 NCKU lecture/Matlab code/database/' ;
scrsz = get(0,'ScreenSize') ;

dbstop if error



% the simulated signal is null or nonnull (2 IMT function)
NONNULLsignal = 1 ;

% if we want to get BS threshold under null
genNULLdist = 1 ;

% carry out power analysis (under nonnull)
POWERanalysis = 0 ;


% if = 1, the noise is PLS, or it is locally stationary (LS)
PLS = 0 ;

% the sampling rate for the simulated signal
Hz = 100 ;
% the number of sampling points of the simulated signal
N = 2^11 ;
% the sampling time of the simulated signal
time = (1:1:N)'/Hz ;

% fix the random seed for the reproducibility issue
initstate(2) ;




 


% this is the order of tvAR
trueb = 2 ;

% generate locally stationary
truephi = zeros(trueb, N) ;
truephi(1,:) = -0.5 * (0.7+0.3*cos(2*pi*(1:N)/N)) ;
truephi(2,:) = 0.3 * sqrt(0.1+(1:N)/N/4) ;
tvsigma = 4 * (1+0.5*cos(2*4*(1:N)'/N+2)) ;

if PLS
    truephi(1,980:end) = 0.5 * (0.6+0.2*cos(2*pi*(980:N)/N)) ;
    truephi(2,980:end) = -0.3 * sqrt(0.2+(980:N)/N/4) ;
    tvsigma(980:end) = 2.2 - tvsigma(980:end) ;
end

BSP.b = 2 ;     % guessed AR order (use the truth)
BSP.m = 16 ;    % number of o.n. basis
BSP.BSno = 1000 ; % number of BS ; (5000 needs 2412 s)
BSP.fHOP = 20 ; % hop for frequency domain
BSP.Ntype = 'T10' ;


% generate noise
[LSnoise] = gentvAR(truephi, tvsigma, random('T', 10, N, 1), BSP) ;




PP.NoWindowsInConceFT = 1 ;
PP.NoConceFT = 1 ;
PP.WindowLength = 477 ; %Hz*4 + 1 ;
PP.WindowBandwidth = 6 ;
PP.SamplingRate = Hz ;
PP.HighFrequencyLimit = 0.5 ;
PP.LowFrequencyLimit = 0 ;
PP.FrequencyAxisResolution = 4e-4 ;
PP.HOP = 25 ;


Alist = linspace(0, 1.2, 6) ;
MCNo = 100 ;


%% generate simulated signal & reconstruct signal when nonnull

% LSnoise is true noise
% s1 is true signal
% xm is noisy signal
% x is estimated noise (in the null case, simply set x = xm)



for MCidx = 1:MCNo
for Aidx = 1:length(Alist)



s1 = zeros(size(LSnoise)) ;
s1hat = zeros(size(LSnoise)) ;
s2 = zeros(size(LSnoise)) ;
s2hat = zeros(size(LSnoise)) ;
if1 = zeros(size(LSnoise)) ;
if2 = zeros(size(LSnoise)) ;
phi1 = zeros(size(LSnoise)) ;
phi2 = zeros(size(LSnoise)) ;
am1 = zeros(size(LSnoise)) ;
am2 = zeros(size(LSnoise)) ;
xm = LSnoise ;
x = LSnoise ;
xhat = zeros(size(LSnoise)) ;

if NONNULLsignal % non-null case (include the reconstruction step)

    fprintf('Generate non-null signal\n')
    
    genSignal ;

    genReconstruction ;

    % plot results -- this is Figure 1
    if 0 && MCidx == 1 && Alist(Aidx) == 1 ; genFigure1 ; end

end






%% tvAR approximation of the noise

fprintf('Apply tvAR to approximate noise\n')

[phihat, sigmaihat] = esttvAR(x, BSP) ;

BSP.Ntype = 'Gaussian' ;
[bsnoise] = gentvAR(phihat, sigmaihat, xhat, BSP) ;

if 0 && MCidx == 1 && Alist(Aidx) == 1 ; genFigure2 ; end












%% generate NULL distribution by BS

% downsample size to save space.
% HOP is time. Also downsample frequency by fHOP
idxf = BSP.fHOP/2: BSP.fHOP: length(tfrticX)-BSP.fHOP/2 ;
idxt = 5:PP.HOP:N ;

downFn = length(idxf) ;
downTn = length(idxt) ;


% generate these percentiles as threshold
THlist = [0.025 0.95 0.975 0.99] ;
genFULL = 1 ;

if genFULL

    % generate REAL null distribution
    %[STFTreal, SSTreal, realSTFTthFULL, realSSTthFULL] = ...
    %    genREALdistribution(truephi, tvsigma, zeros(size(x)), downFn, downTn, PP, BSP, THlist) ;
    BSP.Ntype = 'T10' ;
    [realSTFTth, realSSTth, STFTreal, SSTreal, realSTFTthFULL, realSSTthFULL] =...
        genBSdistribution(truephi, tvsigma, zeros(size(x)), downFn, downTn, PP, BSP, THlist, genFULL) ;

    % generate BS null distribution
    BSP.Ntype = 'Gaussian' ;
    % percentiles in bsSTFTth, bsSSTth are estimated using P2. bsSTFTthFULL, bsSSTthFULL
    % are using the full TFR to calculate all percentiles
    [bsSTFTth, bsSSTth, STFTbs, SSTbs, bsSTFTthFULL, bsSSTthFULL] =...
        genBSdistribution(phihat, sigmaihat, zeros(size(x)), downFn, downTn, PP, BSP, THlist, genFULL) ;

    % plot QQplot of null dist of BS against true -- Figure S4 and Figure S5
    if 0 && MCidx == 1 && Alist(Aidx) == 1 ; genFigureS4S5 ; end

else

    % this one only estimate percentiles using P2. bsSTFTthFULL,
    % bsSSTthFULL are empty matrices. This approach helps increase the
    % number of BS by saving memory. Runtime is the same.
    BSP.Ntype = 'Gaussian' ;
    [bsSTFTth, bsSSTth, STFTbs, SSTbs, bsSTFTthFULL, bsSSTthFULL] ...
        = genBSdistribution(phihat, sigmaihat, zeros(size(x)), downFn, downTn, PP, BSP, THlist, 0) ;

end





%% Detection mission (need full version)
if genFULL

    STFTFisher = zeros(BSP.BSno, length(idxt)) ;
    SSTFisher = zeros(BSP.BSno, length(idxt)) ;
    STFTDETECTED = zeros(1, length(idxt)) ;
    SSTDETECTED = zeros(1, length(idxt)) ;
    
    for jj = 1: length(idxt)
        for kk = 1: BSP.BSno
            STFTFisher(kk, jj) = max(abs(STFTbs(:, idxt(jj), kk))) ;
            SSTFisher(kk, jj) = max(abs(SSTbs(:, idxt(jj), kk))) ;
        end

        if max(abs(tfrX(:, idxt(jj)))) > quantile(STFTFisher(:, jj), .95)
            STFTDETECTED(1, jj) = STFTDETECTED(1, jj) + 1 ;
        end

        if max(abs(tfrsqX(:, idxt(jj)))) > quantile(SSTFisher(:, jj), .95)
            SSTDETECTED(1, jj) = SSTDETECTED(1, jj) + 1 ;
        end
    end
    
end


%% Estimate IF
if genFULL

    c1 = round(if1 ./ (tfrsqticX(2)-tfrsqticX(1)) / Hz) ;
    c2 = round(if2 ./ (tfrsqticX(2)-tfrsqticX(1)) / Hz) ;
    midc = round((c1+c2)/2) ;

    c1hatSTFT = nan(size(c1)) ;
    c2hatSTFT = nan(size(c1)) ;
    c1hatSST = nan(size(c1)) ;
    c2hatSST = nan(size(c1)) ;
    
    % 99 percentile
    for jj = 1: length(c1hat)
        idx = find(abs(tfrX(1:midc(jj), jj))>squeeze(bsSTFTthFULL(1:midc(jj),jj,4))) ;
        if ~isempty(idx)
            [~, tmp2] = max( abs(tfrX(idx, jj)) ) ;
            c1hatSTFT(jj) = idx(tmp2(1));
        end

        idx = find(abs(tfrX(midc(jj)+1:end, jj))>squeeze(bsSTFTthFULL(midc(jj)+1:end,jj,4))) ;
        if ~isempty(idx)
            [~, tmp2] = max( abs(tfrX(midc(jj)+idx, jj)) ) ;
            c2hatSTFT(jj) = midc(jj) + idx(tmp2(1));
        end
   
        idx = find(abs(tfrsqX(1:midc(jj), jj))>squeeze(bsSSTthFULL(1:midc(jj),jj,4))) ;
        if ~isempty(idx)
            [~, tmp2] = max( abs(tfrsqX(idx, jj)) ) ;
            c1hatSST(jj) = idx(tmp2(1));
        end

        idx = find(abs(tfrsqX(midc(jj)+1:end, jj))>squeeze(bsSSTthFULL(midc(jj)+1:end,jj,4))) ;
        if ~isempty(idx)
            [~, tmp2] = max( abs(tfrsqX(midc(jj)+idx, jj)) ) ;
            c2hatSST(jj) = midc(jj) + idx(tmp2(1));
        end
    end

    ERR1STFT = (c1hatSTFT - c1) * (tfrticX(2)-tfrticX(1)) * Hz ;
    ERR2STFT = (c2hatSTFT - c2) * (tfrticX(2)-tfrticX(1)) * Hz ;
    ERR1SST = (c1hatSST - c1) * (tfrsqticX(2)-tfrsqticX(1)) * Hz ;
    ERR2SST = (c2hatSST - c2) * (tfrsqticX(2)-tfrsqticX(1)) * Hz ;

end

disp([mean(ERR1STFT(idxt)) std(ERR1STFT(idxt)) mean(ERR2STFT(idxt)) std(ERR2STFT(idxt))])
disp([mean(ERR1SST(idxt)) std(ERR1SST(idxt)) mean(ERR2SST(idxt)) std(ERR2SST(idxt))])




%% apply the threhold to get the thresholded TFR (use .99 percentile as the threshold)
tfrXth = (abs(tfrX)>squeeze(bsSTFTth(:,:,4))) .* tfrX ;
tfrsqXth = (abs(tfrsqX)>1.1*squeeze(bsSSTth(:,:,4))) .* tfrsqX ;

% Plot STFT/SST threshold -- generate Figure 3
if 0 && MCidx == 1 && Alist(Aidx) == 1  
    genFigure3 ; 
end







%% generate NONNULL distribution and CI by BS
if 0 && MCidx == 1 && Alist(Aidx) == 1 

genFULL = 1 ;

% generate REAL null distribution
%[STFTreal, SSTreal, realSTFTthFULL, realSSTthFULL] = genREALdistribution(...
%    truephi, tvsigma, x, downFn, downTn, PP, BSP, THlist) ;
BSP.Ntype = 'T10' ;
[realSTFTth2, realSSTth2, STFTreal2, SSTreal2, realSTFTthFULL2, realSSTthFULL2] =...
    genBSdistribution(truephi, tvsigma, s1+s2, downFn, downTn, PP, BSP, THlist, genFULL) ;

% generate BS null distribution
BSP.Ntype = 'Gaussian' ;
[bsSTFTth2, bsSSTth2, STFTbs2, SSTbs2, bsSTFTthFULL2, bsSSTthFULL2] =...
    genBSdistribution(phihat, sigmaihat, xhat, downFn, downTn, PP, BSP, THlist, genFULL) ;



% plot CI plot -- generate Figure 3
if 0 ; genFigure4 ; end

% plot QQplot of null dist of BS against true for STFT&SST -- Figure S4
% and Figure S5
if 0 ; genFigureS6S7 ; end

end









%% Run power analysis
% determine threshold under NONNULL & thresholded TFR

if POWERanalysis

    STFTpower0 = zeros(size(STFTbsNONNULL(:,:,1))) ;
    SSTpower0 = zeros(size(STFTbsNONNULL(:,:,1))) ;

    % calculate power to be 1-beta

    for jj = 1: size(STFTQ0,1)
        for kk = 1: size(STFTQ0,2)
            tmp = find(squeeze(abs(STFTbsNONNULL(jj,kk,:))) > STFTQ0(jj, kk)) ;
            STFTpower0(jj, kk) = length(tmp) / BSno ;
            tmp = find(squeeze(abs(SSTbsNONNULL(jj,kk,:))) > SSTQ0(jj, kk)) ;
            SSTpower0(jj, kk) = length(tmp) / BSno ;
        end
    end

    idxf = 10:20:size(tfr2,1)-10 ;
    idxt = 5:HOP:N ;

    %freq x time
    STFTpower = zeros(size(tfrX)) ;
    SSTpower = zeros(size(tfrsqX)) ;
    for jj = 1: size(STFTQ0, 2)
        STFTpower(:, idxt(jj)) = interp1(idxf, STFTpower0(:, jj),...
            1:length(tfrticX), 'linear', 'extrap') ;
        SSTpower(:, idxt(jj)) = interp1(idxf, SSTpower0(:, jj),...
            1:length(tfrsqticX), 'linear', 'extrap') ;
    end

    for jj = 1: size(STFTpower, 1)
        STFTpower(jj, :) = interp1(idxt, STFTpower(jj, idxt),...
            1:size(bsSTFTthNONNULL,2), 'linear', 'extrap') ;
        SSTpower(jj, :) = interp1(idxt, SSTpower(jj, idxt),...
            1:size(bsSTFTthNONNULL,2), 'linear', 'extrap') ;
    end

end








%% TEST: get decomposition after thresholding (not better...)

if 0

    c1 = round(if1 ./ (tfrsqticX(2)-tfrsqticX(1)) / Hz) ;
    tfrsqtmp = tfrsqXth ;
    Q = zeros(71, size(tfrsqX,2)) ;
    for jj = 1: size(tfrsqX,2)
        Q(:, jj) = tfrsqtmp(c1(jj)-35:c1(jj)+35, jj) ;
    end
    [c] = CurveExt_M(abs(Q)', .1) ;
    c1 = c1 + c - 35 -1 ;


    c2 = round(if2 ./ (tfrsqticX(2)-tfrsqticX(1)) / Hz) ;
    tfrsqtmp = tfrsqXth ;
    Q = zeros(71, size(tfrsqX,2)) ;
    for jj = 1: size(tfrsqX,2)
        Q(:, jj) = tfrsqtmp(c2(jj)-35:c2(jj)+35, jj) ;
    end
    [c] = CurveExt_M(abs(Q)', .1) ;
    c2 = c2 + c - 35 -1 ;



    [h, Dh, ttt] = hermf(BW, 1, 6) ;
    Band = 1 ;
    [recon1] = Recon_sqSTFT_v2(tfrsqXth, tfrsqticX, Hz, c1, Band, h((BW+1)/2)) ;
    s1hatthre = real(recon1)' ;
    [recon2] = Recon_sqSTFT_v2(tfrsqXth, tfrsqticX, Hz, c2, Band, h((BW+1)/2)) ;
    s2hatthre = real(recon2)' ;

    disp([norm(s1hat-s1) ./ norm(s1) norm(s2hat-s2) ./ norm(s2)])
    disp([norm(s1hatthre-s1) ./ norm(s1) norm(s2hatthre-s2) ./ norm(s2)])

end