% this is the reconstruction step

[tfrX, tfrticX, tfrsqX, ~, tfrsqticX, ~] = ConceFT_sqSTFT_C(xm, ...
    PP.LowFrequencyLimit, PP.HighFrequencyLimit, PP.FrequencyAxisResolution, ...
    1, PP.WindowLength, PP.NoWindowsInConceFT, PP.WindowBandwidth, PP.NoConceFT, 1, 0) ;



% curve extraction (to avoid the involvement of ridge detection,
% use the true IF to guide the ridge extraction)

c1 = round(if1 ./ (tfrsqticX(2)-tfrsqticX(1)) / Hz) ;
tfrsqtmp = tfrsqX ;
Q = zeros(71, size(tfrsqX,2)) ;
for jj = 1: size(tfrsqX,2)
    Q(:, jj) = tfrsqtmp(c1(jj)-35:c1(jj)+35, jj) ;
end
[c] = CurveExt_M(abs(Q)', .1) ;
c1 = c1 + c - 35 -1 ;


c2 = round(if2 ./ (tfrsqticX(2)-tfrsqticX(1)) / Hz) ;
tfrsqtmp = tfrsqX ;
Q = zeros(71, size(tfrsqX,2)) ;
for jj = 1: size(tfrsqX,2)
    Q(:, jj) = tfrsqtmp(c2(jj)-35:c2(jj)+35, jj) ;
end
[c] = CurveExt_M(abs(Q)', .1) ;
c2 = c2 + c - 35 -1 ;



[h, Dh, ttt] = hermf(PP.WindowLength, 1, 6) ;
Band = 0.8 ;
[recon1] = Recon_sqSTFT_v2(tfrsqX, tfrsqticX, Hz, c1, Band, h((PP.WindowLength+1)/2)) ;
s1hat = real(recon1)' ;
[recon2] = Recon_sqSTFT_v2(tfrsqX, tfrsqticX, Hz, c2, Band, h((PP.WindowLength+1)/2)) ;
s2hat = real(recon2)' ;

% x is the estimated noise
xhat = s1hat + s2hat ;
noisehat = xm - xhat ;




% Generate vanilla SST for oscillation detection
[tfrX, tfrticX, tfrsqX, ~, tfrsqticX, ~] = ConceFT_sqSTFT_C(xm, ...
    PP.LowFrequencyLimit, PP.HighFrequencyLimit, PP.FrequencyAxisResolution, ...
    1, PP.WindowLength, PP.NoWindowsInConceFT, PP.WindowBandwidth, PP.NoConceFT, 0, 1) ;
