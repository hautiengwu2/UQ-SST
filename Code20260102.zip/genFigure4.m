h1 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]) ;


tmp1 = squeeze(realSTFTth2(:,:,1)) ;
SSL1 = quantile(tmp1(:), 1) ;

tmp2 = squeeze(bsSTFTth2(:,:,1)) ;
SSL2 = quantile(tmp2(:), 1) ;

tmp1 = squeeze(realSTFTth2(:,:,3)) ;
SSH1 = quantile(tmp1(:), 1) ;

tmp2 = squeeze(bsSTFTth2(:,:,3)) ;
SSH2 = quantile(tmp2(:), 1) ;


tmp1 = squeeze(realSSTth2(:,:,1)) ;
MML1 = quantile(tmp1(:), 1) ;

tmp2 = squeeze(bsSSTth2(:,:,1)) ;
MML2 = quantile(tmp2(:), 1) ;

tmp1 = squeeze(realSSTth2(:,:,3)) ;
MMH1 = quantile(tmp2(:), 1) ;

tmp2 = squeeze(bsSSTth2(:,:,3)) ;
MMH2 = quantile(tmp2(:), 1) ;




subplot_tight(3, 4, 1, [0.035 0.03]) ;
imagesc(time, tfrsqticX*Hz, squeeze(realSTFTth2(:,:,1)), [0 SSL1]) ; axis xy
colorbar ; ylabel('Freq (Hz)') ; %xlabel('Time (s)') ; 
set(gca, 'fontsize', 16)
text(0.5, 47,'(a)','fontsize', 24) ;

subplot_tight(3, 4, 2, [0.035 0.03]) ;
imagesc(time, tfrsqticX*Hz, squeeze(realSTFTth2(:,:,3)), [0 SSH1]) ; axis xy
colorbar ; 
set(gca, 'fontsize', 16) ; colormap(1-gray)
text(0.5, 47,'(b)','fontsize', 24) ;


subplot_tight(3, 4, 3, [0.035 0.03]) ;
imagesc(time, tfrsqticX*Hz, squeeze(realSSTth2(:,:,1)), [0 MML1]) ; axis xy
colorbar ; %ylabel('Freq (Hz)') ; %xlabel('Time (s)') ; 
set(gca, 'fontsize', 16)
text(0.5, 47,'(c)','fontsize', 24) ;

subplot_tight(3, 4, 4, [0.035 0.03]) ;
imagesc(time, tfrsqticX*Hz, squeeze(realSSTth2(:,:,3)), [0 MMH2]) ; axis xy
colorbar ; 
set(gca, 'fontsize', 16) ; colormap(1-gray)
text(0.5, 47,'(d)','fontsize', 24) ;



subplot_tight(3, 4, 5, [0.035 0.03]) ;
imagesc(time, tfrsqticX*Hz, squeeze(bsSTFTth2(:,:,1)), [0 SSL2]) ; axis xy
colorbar ; xlabel('Time (s)') ; ylabel('Freq (Hz)')
set(gca, 'fontsize', 16) ; colormap(1-gray)
text(0.5, 47,'(e)','fontsize', 24) ;

subplot_tight(3, 4, 6, [0.035 0.03]) ;
imagesc(time, tfrsqticX*Hz, squeeze(bsSTFTth2(:,:,3)), [0 SSH2]) ; axis xy
colorbar ; xlabel('Time (s)') ;
set(gca, 'fontsize', 16) ; colormap(1-gray)
text(0.5, 47,'(f)','fontsize', 24) ;


subplot_tight(3, 4, 7, [0.035 0.03]) ;
imagesc(time, tfrsqticX*Hz, squeeze(bsSSTth2(:,:,1)), [0 MML2]) ; axis xy
colorbar ; xlabel('Time (s)') ; 
set(gca, 'fontsize', 16) ; colormap(1-gray)
text(0.5, 47,'(g)','fontsize', 24) ;

subplot_tight(3, 4, 8, [0.035 0.03]) ;
imagesc(time, tfrsqticX*Hz, squeeze(bsSSTth2(:,:,3)), [0 MMH2]) ; axis xy
colorbar ; xlabel('Time (s)') ;
set(gca, 'fontsize', 16) ; colormap(1-gray)
text(0.5, 47,'(h)','fontsize', 24) ;


if SAVEFIG
    exportgraphics(h1, 'Figure4AHM2CI_TFR.pdf', 'ContentType', 'vector', 'BackgroundColor','none') ;
    close
end