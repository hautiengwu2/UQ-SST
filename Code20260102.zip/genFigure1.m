h1 = figure('Position',[1 scrsz(4) scrsz(3)*3/4 scrsz(4)*3/4]) ;

subplot_tight(4, 1, 1, [0.042 0.05])
plot(time, xm, 'k', 'linewidth',2); hold on ;
plot(time, s1+s2, 'color', [.6 .6 .6], 'linewidth',2); hold on ;
ylabel('a.u.') ; text(1.05, 18,'(a)','fontsize', 24) ;
set(gca, 'fontsize', 16) ; axis([1 8 -inf inf]) ;

subplot_tight(4, 1, 2, [0.042 0.05])
plot(time, real(recon1+recon2)', 'k', 'linewidth',2); hold on ;
plot(time, s1+s2, 'color', [.6 .6 .6], 'linewidth',2); hold on ;
ylabel('a.u.') ; text(1.05, 5,'(b)','fontsize', 24) ;
set(gca, 'fontsize', 16) ; axis([1 8 -inf inf]) ;

subplot_tight(4, 1, 3, [0.042 0.05])
plot(time, x, 'k', 'linewidth',2); hold on ;
plot(time, LSnoise, 'color', [.6 .6 .6], 'linewidth',2); hold on ;
xlabel('Time (sec)') ; ylabel('a.u.') ; axis([1 8 -inf inf]) ;
set(gca, 'fontsize', 16) ; 
text(1.05, 18,'(c)','fontsize', 24) ;

if SAVEFIG
    exportgraphics(h1, 'Figure1AMH2Decomp.pdf', 'ContentType', 'vector', 'BackgroundColor','none');
    close
end