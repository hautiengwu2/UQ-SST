function [STFTreal, SSTreal, realSTFTthFULL, realSSTthFULL] =...
    genREALdistribution(truephi, tvsigma, x, downFn, downTn, PP, BSP, thre) 

N = length(tvsigma) ;
trueb = size(truephi, 1) ;

fprintf('Generate REAL distribution under null hypothesis\n')

STFTreal = zeros(downFn, downTn, BSP.BSno) ;
SSTreal = zeros(downFn, downTn, BSP.BSno) ;

t1 = tic ;

% generate real null distribution
for qqq = 1: BSP.BSno

    waitbar(qqq/BSP.BSno)

    % generate "true distribution"
    noise = zeros(N, 1) ;
    noise(1:trueb) = randn(trueb, 1) ;
    for kk = trueb+1: N
        noise(kk) = truephi(1:trueb, kk)' * noise(kk-(1:trueb)) + tvsigma(kk)*randn(1) ;
    end

    [tfr, tfrtic, tfrsq, ~, ~, ~] = ConceFT_sqSTFT_C(...
        x+noise, PP.LowFrequencyLimit, ...
        PP.HighFrequencyLimit, PP.FrequencyAxisResolution, PP.HOP, PP.WindowLength, ...
        PP.NoWindowsInConceFT, PP.WindowBandwidth, PP.NoConceFT, 0, 1) ;

    % avoid the boundary issue.
    STFTreal(:, :, qqq) = tfr(BSP.fHOP/2: BSP.fHOP: length(tfrtic)-BSP.fHOP/2, :) ;
    SSTreal(:, :, qqq) = tfrsq(BSP.fHOP/2: BSP.fHOP: length(tfrtic)-BSP.fHOP/2, :) ;
end





realSTFTthFULL = zeros(size(tfr,1), N, length(thre)) ;
realSSTthFULL = zeros(size(tfr,1), N, length(thre)) ;

for kk = 1: length(thre)

    % this is the percentile of sparse TF points
    TFRQ0 = zeros(size(STFTreal(:,:,1))) ;
    for jj = 1: size(TFRQ0,1)
        for ll = 1: size(TFRQ0,2)
            TFRQ0(jj, ll) = quantile(squeeze(abs(STFTreal(jj,ll,:))), thre(kk)) ;
        end
    end

    % extend the threshold over sparse grid to the full grid
    [tmp] = extTFRthreFULL(TFRQ0, size(tfr,1), N, PP, BSP) ;
    realSTFTthFULL(:, :, kk) = tmp ;


    TFRQ0 = zeros(size(SSTreal(:,:,1))) ;
    for jj = 1: size(TFRQ0,1)
        for ll = 1: size(TFRQ0,2)
            TFRQ0(jj, ll) = quantile(squeeze(abs(SSTreal(jj,ll,:))), thre(kk)) ;
        end
    end

    [tmp] = extTFRthreFULL(TFRQ0, size(tfrsq,1), N, PP, BSP) ;
    realSSTthFULL(:, :, kk) = tmp ;
end


toc(t1)



