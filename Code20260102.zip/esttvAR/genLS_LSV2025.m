function [xLSV] = genLS_LSV2025(x)
%
% This is an implementation of Bootstrap Inference in Linear Time-Varying 
% Coefficient Models in Locally Stationary Time Series
% by Yicong Lin, Mingxuan Song & Bernhard van der Sluis, 2025

%
x = x(:) ;
n = length(x) ;

l = round(4.5 * n^(0.25)) ;
N = ceil(n/l) ;

U = zeros(l, n-l+1) ;
for jj = 1: n-l+1
    U(:, jj) = x(jj: jj+l-1) ;
end

% modified version. In the original paper, it is randn(1) that is
% suggested. But it seems +1/-1 version is much better for our purpose.
Ustar = zeros(l, N) ;
for ii = 1: N
    cUidx = max(1, ii*l - 2*l + 1): min(ii*l + 1, n-l+1) ;
    pii = ceil(rand(1) * length(cUidx)) ;
    %Ustar(:, ii) = randn(1) * U(:, cUidx(pii)) ;
    Ustar(:, ii) = (2*(rand(1)>0.5)-1) * U(:, cUidx(pii)) ;
end

xLSV = Ustar(:) ; 
xLSV = xLSV(1:n) ;