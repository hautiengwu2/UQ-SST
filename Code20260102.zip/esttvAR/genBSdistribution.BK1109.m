function [STFTbs, SSTbs, bsSTFTth, bsSSTth, bsSTFTthFULL, bsSSTthFULL] ...
    = genBSdistribution(phihat, sigmai, x, downFn, downTn, PP, BSP, thre, genFULL)


t1 = tic ;
if genFULL
    STFTbs = zeros(downFn, downTn, BSP.BSno) ;
    SSTbs = zeros(downFn, downTn, BSP.BSno) ;
else
    STFTbs = [] ;
    SSTbs = [] ;
end

bsSTFTth0 = arrayfun(@(~) P2(thre), cell(downFn, downTn), 'UniformOutput', false) ;
bsSSTth0 = arrayfun(@(~) P2(thre), cell(downFn, downTn), 'UniformOutput', false) ;

for qqq = 1: BSP.BSno

    if ~mod(qqq, 100) ; waitbar(qqq/BSP.BSno) ; end

    % generate "bootstrapped distribution"
    [bsnoise] = gentvAR(phihat, sigmai, x, BSP) ;

    [tfr, tfrtic, tfrsq, ~, ~, ~] = ConceFT_sqSTFT_C(...
        x+bsnoise, PP.LowFrequencyLimit, ...
        PP.HighFrequencyLimit, PP.FrequencyAxisResolution, PP.HOP, PP.WindowLength, ...
        PP.NoWindowsInConceFT, PP.WindowBandwidth, PP.NoConceFT, 0, 1) ;
    
    if qqq == 1
        idxf = BSP.fHOP/2: BSP.fHOP: length(tfrtic)-BSP.fHOP/2 ;
    end

    if genFULL
        STFTbs(:, :, qqq) = tfr(idxf, :) ;
        SSTbs(:, :, qqq) = tfrsq(idxf, :) ;
    end


    for kk = 1: downFn
        for ll = 1: downTn
            bsSTFTth0{kk, ll}.add(abs(tfr(idxf(kk), ll))) ;
            bsSSTth0{kk, ll}.add(abs(tfrsq(idxf(kk), ll))) ;
        end
    end


end


% this is the FULL threshold result
if genFULL


    bsSTFTthFULL = zeros(size(tfr,1), length(x), length(thre)) ;
    bsSSTthFULL = zeros(size(tfr,1), length(x), length(thre)) ;

    for kk = 1: length(thre)

        % this is the percentile of sparse TF points
        TFRQ0 = zeros(size(STFTbs(:,:,1))) ;
        for jj = 1: size(TFRQ0,1)
            for ll = 1: size(TFRQ0,2)
                TFRQ0(jj, ll) = quantile(squeeze(abs(STFTbs(jj,ll,:))), thre(kk)) ;
            end
        end

        % extend the threshold over sparse grid to the full grid
        [tmp] = extTFRthreFULL(TFRQ0, size(tfr,1), length(x), PP, BSP) ;
        bsSTFTthFULL(:, :, kk) = tmp ;


        TFRQ0 = zeros(size(SSTbs(:,:,1))) ;
        for jj = 1: size(TFRQ0,1)
            for ll = 1: size(TFRQ0,2)
                TFRQ0(jj, ll) = quantile(squeeze(abs(SSTbs(jj,ll,:))), thre(kk)) ;
            end
        end

        [tmp] = extTFRthreFULL(TFRQ0, size(tfrsq,1), length(x), PP, BSP) ;
        bsSSTthFULL(:, :, kk) = tmp ;
    end

else

    bsSTFTthFULL = [] ; bsSSTthFULL = [] ;

end


% this is the P2 threshold result
bsSTFTth1 = zeros(downFn, downTn, length(thre)) ;
bsSSTth1 = zeros(downFn, downTn, length(thre)) ;

for kk = 1: downFn
    for ll = 1: downTn
        bsSTFTth1(kk, ll, :) = bsSTFTth0{kk, ll}.resultAll() ;
        bsSSTth1(kk, ll, :) = bsSSTth0{kk, ll}.resultAll() ;
    end
end

bsSTFTth = zeros(size(tfr,1), length(x), length(thre)) ;
bsSSTth = zeros(size(tfr,1), length(x), length(thre)) ;

for kk = 1: length(thre)
    [tmp] = extTFRthreFULL(squeeze(bsSTFTth1(:, :, kk)), size(tfr,1), length(x), PP, BSP) ;
    bsSTFTth(:, :, kk) = tmp ;

    [tmp] = extTFRthreFULL(squeeze(bsSSTth1(:, :, kk)), size(tfrsq,1), length(x), PP, BSP) ;
    bsSSTth(:, :, kk) = tmp ;
end

toc(t1)