function [phihat] = fittvARcoeff(x, b, c) 
% b: the order of tvAR
% Sieve approach to estimate tvAR approximation of 
% locally stationary random process (Ding & Zhou 2023 AoS)

x = x(:) ; 
N = length(x) ;

% c needs an estimate with CV

[B0, ~] = genWaveletBasis(N, log2(N)-4, 'db6') ;
B = B0(N-c+1: N, :) ;

if 0
    B = zeros(c, N) ;
    B(1,:) = ones(1,N) ; B(1,:) = B(1,:) ./ norm(B(1,:)) ;
    for jj = 1: c/2-1
        B(2*jj, :) = cos(2*pi*jj*(1:N)/N) ;
        B(2*jj, :) = B(2*jj, :) ./ norm(B(2*jj, :)) ;
        B(2*jj+1, :) = sin(2*pi*jj*(1:N)/N) ;
        B(2*jj+1, :) = B(2*jj+1, :) ./ norm(B(2*jj+1, :)) ;
    end
    B(c, :) = cos(2*pi*(c/2)*[1:N]/N) ;
    B(c, :) = B(c, :) ./ norm(B(c, :)) ;
end


XX = zeros(N-b, b) ;
for ii = 1: N-b
    XX(ii, :) = x(ii+b-1:-1:ii) ; 
end

BJ = B(:, b+1:end) ;

sI = 1: N-b ;
sJ = (sI-1)*(N-b) + sI ;
D = sparse(sI, sJ, ones(1,N-b), N-b, (N-b)^2, N-b) ;

Q = D * kron(BJ', XX) ;
    

xx = x(b+1: N) ;

% beta is a bxc matrix, and vbetahat is an estimate of vec(beta)
vbetahat = inv(Q'*Q) * Q' * xx ;
betahat = reshape(vbetahat, b, c) ;


phihat = zeros(b, N) ;
for jj = 1: b
    phihat(jj, :) = betahat(jj,:) * B ;
end