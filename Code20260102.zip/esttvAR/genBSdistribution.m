function [STFTbs, SSTbs, STFTbsTH, SSTbsTH] ...
    = genBSdistribution(PP, BSP, thre, genFULL)


t1 = tic ;
if genFULL
    STFTbs = zeros(BSP.Fn, BSP.downTn, BSP.BSno) ;
    SSTbs = zeros(BSP.Fn, BSP.downTn, BSP.BSno) ;
else
    STFTbs = [] ;
    SSTbs = [] ;
    STFTbsTH0 = arrayfun(@(~) P2(thre), cell(BSP.downFn, BSP.downTn), 'UniformOutput', false) ;
    SSTbsTH0 = arrayfun(@(~) P2(thre), cell(BSP.downFn, BSP.downTn), 'UniformOutput', false) ;
end


for qqq = 1: BSP.BSno

    if ~mod(qqq-1, 50) || qqq==BSP.BSno ; waitbar(qqq/BSP.BSno) ; end

    
    if BSP.MODEL == 1
        % generate "true model noise"
        [bsnoise, ~, ~] = genNoise(length(x), BSP) ;
    else
        % generate "bootstrapped noise"
        if strcmp(BSP.type, 'DZ2022') 
            [bsnoise] = gentvAR(BSP.phihat, BSP.sigmai, BSP) ;
        elseif strcmp(BSP.type, 'KP2015')
            [bsnoise] = genLS_KP2015(BSP.noisehat, kurtosis(random('T', 10, length(BSP.xhat), 1))-3) ;
        elseif strcmp(BSP.type, 'HK2017')
            [bsnoise] = genLS_HK2017(BSP.noisehat) ;
        elseif strcmp(BSP.type, 'Poskitt2025')
            [bsnoise] = genLS_Poskitt2025(BSP.noisehat) ;
        elseif strcmp(BSP.type, 'LSV2025') 
            [bsnoise] = genLS_LSV2025(BSP.noisehat) ;            
        end
    end

    [tfr, tfrtic, tfrsq, ~, ~, ~] = ConceFT_sqSTFT_C(...
        BSP.xhat + bsnoise, PP.LowFrequencyLimit, ...
        PP.HighFrequencyLimit, PP.FrequencyAxisResolution, PP.HOP, PP.WindowLength, ...
        PP.NoWindowsInConceFT, PP.WindowBandwidth, PP.NoConceFT, 0, 1) ;
    
    if qqq == 1
        idxf = BSP.fHOP/2: BSP.fHOP: length(tfrtic)-BSP.fHOP/2 ;
    end

    if genFULL
        STFTbs(:, :, qqq) = tfr ;
        SSTbs(:, :, qqq) = tfrsq ;    
    else

        for kk = 1: downFn
            for ll = 1: downTn
                STFTbsTH0{kk, ll}.add(abs(tfr(idxf(kk), ll))) ;
                SSTbsTH0{kk, ll}.add(abs(tfrsq(idxf(kk), ll))) ;
            end
        end

    end
end


STFTbsTH = zeros(BSP.downFn, BSP.downTn, length(thre)) ;
SSTbsTH = zeros(BSP.downFn, BSP.downTn, length(thre)) ;

if genFULL

    for kk = 1: length(thre)

        % this is the percentile of sparse TF points
        for jj = 1: BSP.downFn
            for ll = 1: BSP.downTn
                STFTbsTH(jj, ll, kk) = quantile(squeeze(abs(STFTbs(idxf(jj),ll,:))), thre(kk)) ;
            end
        end


        for jj = 1: BSP.downFn
            for ll = 1: BSP.downTn
                SSTbsTH(jj, ll, kk) = quantile(squeeze(abs(SSTbs(idxf(jj),ll,:))), thre(kk)) ;
            end
        end
        
    end

else

    % this is the P2 threshold result
    for kk = 1: BSP.downFn
        for ll = 1: BSP.downTn
            STFTbsTH(kk, ll, :) = STFTbsTH0{kk, ll}.resultAll() ;
            SSTbsTH(kk, ll, :) = SSTbsTH0{kk, ll}.resultAll() ;
        end
    end

end

toc(t1)


