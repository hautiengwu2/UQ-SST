function [xHK1] = genLS_HK2017(x)
%
% This code implements Häfner & Kirch's 2017 mTFT bootstrap for LS in
% "Moving Fourier Analysis for Locally Stationary Processes with the Bootstrap in View."
%

x = x(:) ;
n = length(x) ; % this is T in HK2017


% preparation in section KP2015, section 4.1
ctilde0 = zeros(1, n) ;
ctilde1 = zeros(1, n) ;
T = 6 ;
[h] = hermf(T, 1, 4) ; h = h(:) ;
HT = sum(h.^2) ;

for jj = 1: n
    tmp = x(mod((jj-T/2+1:jj+T/2)-1, n)+1) ;
    ctilde0(jj) = (h.^2)' * (tmp.^2) / HT ; 
    tmpt = x(mod((jj-T/2+1:jj+T/2-1)-1, n)+1) ;
    tmps = x(mod((jj-T/2:jj+T/2-2)-1, n)+1) ;
    ctilde1(jj) = (h(1:end-1).*h(2:end))' * (tmpt.*tmps) / HT ; 
end

phihat = ctilde1 ./ ctilde0 ;
lambdalist = linspace(-pi, pi, T)' ;
ghat = 1 + ones(T,1) * phihat.^2 -  cos(lambdalist) * 2*phihat ;

Du = pi * sum( sum( (log( ghat(:, T/2+1: n-T/2) ./ ghat(:, T/2-1:n-T/2-2) )).^2, 1), 2) / T ;
Dl = pi * sum( sum( (log( ghat(3:end, T/2+1: n-T/2) ./ ghat(1:end-2, T/2+1:n-T/2) )).^2, 1), 2) / n ;


tauhat = ((576*pi/n)^(1/6)) * (Dl / Du^5)^(1/12) ; 
bhat = ((576*pi/n)^(1/6)) * (Du / Dl^5)^(1/12) ; 

% M is the order of MF in Def 2.1
M = round(tauhat * n/2) ;


% this is local periodogram
Itilde = zeros(2*M+1, n) ;

for jj = 1: n
    tmp = fft(x(mod((jj-M:jj+M)-1, n)+1)) ./ sqrt(2*M+1) ;    
    Itilde(:, jj) = abs(tmp).^2 ;
end



% estimate tvPS of x
fhat = zeros(2*M+1, n) ;

% the spectral band is from -pi to pi
Kb = 6 * (1/4 - (linspace(-bhat, bhat, round(bhat*(2*M+1)/pi))./ bhat/2).^2) ;

for jj = 1: n
    fhat(:, jj) = conv(Itilde(:, jj), Kb, 'same') / length(Kb) ;
    % force symmetry. Here 2*M+1 is odd.
    fhat(end:-1:(end-1)/2+2, jj) = fhat(2:(end+1)/2, jj) ;
end

fhatsr = fhat.^(1/2) ;


% generate innovation
MFkstar = zeros(1, n) ;

for jj = 1: n
    MFkstar(jj) = fhatsr(mod(jj-1, M)+1, jj) * (randn(1)+ 1i*randn(1)) ;
end

MFstar = zeros(2*M+1, n) ;

for tt = 1: n
    mt = mod(tt-1, M) + 1 ;
    for ll = 1: M
        if ll - mt >= ceil(M/2)
            idx = tt - mt + ll - M ;
        elseif ll - mt < -ceil(M/2) 
            idx = tt - mt + ll + M ;
        else
            idx = tt - mt + ll ;
        end
        MFstar(ll+1, tt) = MFkstar(mod(idx-1, n)+1) ;
        MFstar(2*M+1-ll+1, tt) = conj(MFkstar(mod(idx-1, n)+1)) ;
    end
end


% generate bootstrapped noise
xHK1 = zeros(size(x)) ;

for jj = 1: length(x)
    E = exp(1i*2*pi* (1:M)'/(2*M+1) * jj) ;
    xHK1(jj) = real(transpose(MFstar(2:M+1, jj)) * E) * 2 / sqrt(2*M+1) ;
end