function [STFTbsTH, SSTbsTH] = genBSTHDense(STFTbsTH0, SSTbsTH0, PP, BSP)

STFTbsTH = zeros(BSP.Fn, BSP.Tn, size(STFTbsTH0, 3)) ;
SSTbsTH = zeros(BSP.Fn, BSP.Tn, size(STFTbsTH0, 3)) ;

for kk = 1: size(STFTbsTH0, 3)
    [tmp] = extTFRthreDense(squeeze(STFTbsTH0(:, :, kk)), PP, BSP) ;
    STFTbsTH(:, :, kk) = tmp ;

    [tmp] = extTFRthreDense(squeeze(SSTbsTH0(:, :, kk)), PP, BSP) ;
    SSTbsTH(:, :, kk) = tmp ;
end




function [bsTFRth] = extTFRthreDense(TFRQ0, PP, BSP)

bsTFRth = zeros(BSP.Fn, BSP.Tn) ;

idxf = BSP.fHOP/2: BSP.fHOP: BSP.Fn-BSP.fHOP/2 ;
idxt = 5: PP.HOP: BSP.Tn ;

% interpolate to obtain threshold of TF domain
for jj = 1: size(TFRQ0, 2)
    bsTFRth(:, idxt(jj)) = interp1(idxf, TFRQ0(:, jj), 1:BSP.Fn, 'linear', 'extrap') ;
end

for jj = 1: BSP.Fn
    bsTFRth(jj, :) = interp1(idxt, bsTFRth(jj, idxt), 1:BSP.Tn, 'linear', 'extrap') ;
end
