function [bsnoise] = gentvAR(phihat, sigmai, BSP)

b = BSP.b ;
m = BSP.m ;
N = size(phihat, 2) ;

bsnoise = zeros(N, 1) ;
bsnoise(1:b) = BSP.noisehat(1:b) ;

for kk = b+1: N
    if strcmp(BSP.noisetype, 'T10') 
        bsnoise(kk) = phihat(1:b, kk)' * bsnoise(kk-(1:b)) + sigmai(kk) * random('T', 10, 1, 1) ;
    else
        bsnoise(kk) = phihat(1:b, kk)' * bsnoise(kk-(1:b)) + sigmai(kk) * randn(1) ;
    end
end
