function [phihat, sigmai] = esttvAR(NoiseEST, BSP)
%
% b: estimated AR order
% m: number of o.n wavelet basis for coefficient fitting
% 
% eg. b = 2 ; m = 16 ; [phihat, sigmai] = esttvAR(signal, b, m) ;

b = BSP.b ;
m = BSP.m ;

% currently, N must be a power of 2. UPDATE it!
N = length(NoiseEST) ;

t1 = tic ;

if ~bitand(N, N-1)

    [phihat] = fittvARcoeff(NoiseEST', b, m) ;

    % estimate time-varying white noise
    ei = zeros(N, 1) ;
    ei(1:b) = NoiseEST(1:b)' ;
    for kk = b+1: N
        ei(kk) = NoiseEST(kk) - phihat(1:b, kk)' * NoiseEST(kk-(1:b)) ;
    end

    % estimate the time-varying SD
    sigmai = zeros(N, 1) ;
    for kk = b+1: N
        idx = max(1, kk-20): min(kk+20, N) ;
        sigmai(kk) = std(ei(idx)) ;
    end

else

    fprintf('ERROR! not doing anything\n')
    phihat = [] ;
    sigmai = [] ;

end

toc(t1) ;