#include <iostream.h>
#include <fstream.h>
#include <math.h>
#include <stdlib.h>
#include "avedif.h"

#ifndef reverse_H
#define reverse_H

const double lor[fillen]={0.48296291314469,  0.83651630373747,
                          0.22414386804186, -0.12940952255092};
const double hir[fillen]={-0.12940952255092,-0.22414386804186,
                           0.83651630373747,-0.48296291314469};

/*
const double a11=0.43748104935578;
const double a12=0.31510759561939;
const double a13=0.35145685488987;
const double a21=0.01218682867224;
const double a22=0.81214264639312;
const double a23=0.90582741955871;
const double a31=0.00703606881449;
const double a32=0.46889077551570;
const double a33=-1.78642137223734;

const double b11=0.83651630373758;
const double b12=0.99999999999933;
const double b21=0.48296291314467;
const double b22=-1.73205080756964;
*/ 
int main_reverse(void);

#endif
