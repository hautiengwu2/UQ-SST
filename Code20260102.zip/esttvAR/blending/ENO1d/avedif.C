#include <fstream.h>
#include <iostream.h>
#include <math.h>
#include <stdlib.h>
#include "avedif.h"

int main_avedif()
{ 
   int h, l;
   int j;
 
   l=n;
   h=0;
   for (j=1; j<=N; j++) 
   {
     if (l%2==0)
       l=l/2+1;
     else
       l=(l+1)/2+1;
     h=h+l; 
   }
   cout << l << " "  << h << endl;
   cout.precision(14);
 
   int* sign;
   double* ave; 
   double* dif;
   //double a[n]={0.0000,0.0000,0.0000,0.0000,0.0000,0.0947,0.0947,
   //       0.0947,0.0947, 0.0947,0.0947,0.0947,0.0000,0.0000,0.0000,0.0000 };
   double a[n];
 
   sign=new int[h];
   ave=new double[l];
   dif=new double[h];
   
   init_signal(a,n);
   /*ifstream avetempins;
   avetempins.open("avetemp.dat");
   if (avetempins.fail())
   {
     cout << "input file avetemp.dat opening failed. \n";
     exit(1);
   }
   */

   ave_dif(a,n,ave,l,dif,h,sign,N);
   
   ofstream aveouts;
   aveouts.open("average.dat");
   if (aveouts.fail())
   {
     cout << "output file average.dat opening failed. \n";
     exit(1);
   }
   aveouts.precision(14);

   ofstream difouts;
   difouts.open("difference.dat");
   if (difouts.fail())
   {
     cout << "output file difference.dat opening failed. \n";
     exit(1);
   }
   difouts.precision(14);

   ofstream signouts;
   signouts.open("sign.dat");
   if (signouts.fail())
   {
     cout << "output file sign.dat opening failed. \n";
     exit(1);
   }
   
   for (int i=0; i<l; i++)
   {
     aveouts << ave[i] << " ";
     //cout << ave[i] << " ";
   }
   //cout << endl;
 
   for (i=0; i<h; i++)
   {
     difouts << dif[i] << " ";
     signouts << sign[i] << " "; 
     //cout << dif[i] << " ";
     //cout << sign[i] << " ";
   }
   //cout << endl;
   
   aveouts.close();
   difouts.close();
   signouts.close();

   return 0;
}

void init_signal(double* a, int n)
{

   double p0=0.200, p1=0.4, p2=1.1, p3=1.6;
   //double p0=0.2, p1=0.4, p2=1.2, p3=1.0/255*450;
   double h=2.0/(n-1);
   // at p1 and p2, the function has jumps.

   ofstream initouts;
   initouts.open("initial.dat");
   if (initouts.fail())
   {
      cout << " output file initial.dat opening failed. \n";
      exit(1);
   }
   initouts.precision(14);
 
   for (int i=0; i<n; i++)
   {
      if (i*h<p0)
       a[i]=0;
      else if ( (i*h>=p0) && (i*h<p1) )
       //a[i]=10*sin(i*h*4*pi+0.80*pi);
       //a[i]=20;
       a[i]=-50*i*h-5;
      else if ( (i*h>=p1) && (i*h<p2) )
       a[i]=10*sin(i*h*4*pi+0.80*pi)-1;
       //a[i]=100*pow(h*i-0.7,2)-10;
       //a[i]=0; //100*h*i-10;
      else if ( (i*h>=p2) && (i*h<p3) )
       //a[i]=10;
       a[i]=5*exp(2*i*h)-100;
      //else if ( (i*h>=p3) && (i*h<p4) )
      // a[i]=0;
      //else if ( (i*h>=p4) && (i*h<p5) )
       //a[i]=700*pow((i*h)-1.5,3)-50;
       //a[i]=-30*h*i-5;
       //a[i]=20*(i*h-p5)+(p5-p4)*20;
      // a[i]=5;
      //else if ( (i*h>=p5) && (i*h<p6) )
       //a[i]=-20*(i*h-p5)+(p5-p4)*20;
      //else if (i*h>=p0 && i*h<p5)
      // a[i]=20;
      else
       a[i]=0;
 
      double temp=gauss_generator(0.0,0.3);
      a[i]=a[i]+tense*temp;
 
      //a[i]=exp(-(2/((i+1)*h)+1/(1-(i-1)*h/2)));
      //a[i]=pow((i*h),5); 
      initouts << a[i] << " "; 
      //cout << a[i] << " ";
   }
   
   initouts.close();
}


void ave_dif(double* a, int n, double* ave, 
            int l, double* dif, int h, int* sign, int N)
{
   int i, j;
   double tempdif1=0, tempdif2=1, tempdif3=1;
   int startstore=h;
   int index=n;
   int index_old=index;
   double tempa1=0, tempd1=0, tempa2=0, tempd2=0;
   double tempx1=0, tempx2=0;

   double coef, coef0, coef1, coef2, coef3;
   double ratio, ratio2, ratio3;
 
   ratio=lod[0]/hid[0]; 
   ratio2=lod[2]-ratio*hid[2];
   ratio3=lod[3]-ratio*hid[3];

   coef=hid[3]/lod[3];
   coef0=hid[0]-coef*lod[0];
   coef1=hid[1]-coef*lod[1];
   coef2=hid[2]-coef*lod[2];
   coef3=hid[3]-coef*lod[3];

   doubleptr a_temp;
 
   for (j=1; j<=N; j++)
   {
    intptr sign_temp;
    doubleptr ave_temp;
    doubleptr dif_temp;   
    
    index_old=index;

    if (index%2==0)
       index=index/2+1;
    else
       index=(index+1)/2+1;

    if (j==1)
    {
       sign_temp=new int[index];
       ave_temp=new double[index];
       dif_temp=new double[index];
    }

    if (index_old%2==0)
    {
       a_temp=new double[index_old];
       if (j>1)
       {
         for (i=0; i<index_old; i++)
           a_temp[i]=ave_temp[i];
       }  
    }
    else
    {
       a_temp=new double[index_old+1];
       if (j>1)
       {
         for (i=0; i<index_old; i++)
           a_temp[i]=ave_temp[i];
         a_temp[index_old]=0;
       }
    }
 
    startstore=startstore-index;
    
    index_old=index;
 
    if (j != 1)
    { 
      delete [] ave_temp;
      delete [] dif_temp;
      delete [] sign_temp;
    }
 
    ave_temp=new double[index];
    dif_temp=new double[index];
    sign_temp=new int[index];

    if (j==1)
    {
     for (i=0; i<n; i++)
     {
      a_temp[i]=a[i];
     }
    }

    int left=0, k;

    for (i=0; i<index; i++)
    { 
      sign_temp[i]=0;
      int l_temp=index-1;
      if (i==l_temp) 
      {
         ave_temp[i]=(lod[0]*a_temp[2*i-2]+lod[1]*a_temp[2*i-1]);
         dif_temp[i]=(hid[0]*a_temp[2*i-2]+hid[1]*a_temp[2*i-1]);
      }
      else if (i==0)
      {
         ave_temp[i]=(lod[2]*a_temp[2*i]+lod[3]*a_temp[2*i+1]);
         dif_temp[i]=(hid[2]*a_temp[2*i]+hid[3]*a_temp[2*i+1]);
      }
      else if ((i<=2) && (i>=index-2))
      {
         ave_temp[i]=(lod[0]*a_temp[2*i-2]+lod[1]*a_temp[2*i-1]
                      +lod[2]*a_temp[2*i]+lod[3]*a_temp[2*i+1]);
         dif_temp[i]=(hid[0]*a_temp[2*i-2]+hid[1]*a_temp[2*i-1]
                      +hid[2]*a_temp[2*i]+hid[3]*a_temp[2*i+1]);
      }
      else
      { 
         ave_temp[i]=(lod[0]*a_temp[2*i-2]+lod[1]*a_temp[2*i-1]+
                      lod[2]*a_temp[2*i] + lod[3]*a_temp[2*i+1]);
         dif_temp[i]=(hid[0]*a_temp[2*i-2]+hid[1]*a_temp[2*i-1]+
                        hid[2]*a_temp[2*i]+hid[3]*a_temp[2*i+1]);

         //tempdif2=(hid[0]*a_temp[2*i-2]+hid[1]*a_temp[2*i-3]+
         //         hid[2]*a_temp[2*i-4]+hid[3]*a_temp[2*i-5]);

         tempdif2=dif_temp[i-1];
         
         //cout << dif_temp[i] << " " << tempdif2 << endl;
         //dif_temp[i]=minbar(tempdif1,tempdif2);
         
         if ( (fabs(dif_temp[i])>alpha*fabs(tempdif2)) 
             && ( fabs(dif_temp[i])>epsilon) && turn==0)
         {
           sign_temp[i]=1;
           k=i-1;
           if (sign_temp[k]==0)
             left=left+1;
           else
           {
            while (left>0) 
            {
              tempa1=2*ave_temp[k-1]-ave_temp[k-2];
              dif_temp[k]=coef*tempa1+coef0*a_temp[2*k-2]+coef1*a_temp[2*k-1];
              tempx1=(tempa1-(lod[0]*a_temp[2*k-2]+lod[1]*a_temp[2*k-1]
                             +lod[2]*a_temp[2*k]))/lod[3];
              tempa2=2*tempa1-ave_temp[k-1];
              dif_temp[i]=coef*tempa2+coef0*a_temp[2*k]+coef1*tempx1;
              tempx2=-(hid[1]*a_temp[2*k+1]+hid[2]*a_temp[2*k+2]
                       +hid[3]*a_temp[2*k+3])/hid[0];
              ave_temp[i]=lod[0]*tempx2+lod[1]*a_temp[2*k+1]
                          +lod[2]*a_temp[2*k+2]+lod[3]*a_temp[2*k+3];
              ave_temp[k]=ratio2*tempx2+ratio3*a_temp[2*k+1];
              left=left-1;
            }
           }
         }
         else
         {
           while (left>0)
           {
             k=i-1;              
             ave_temp[k]=ratio2*a_temp[2*k]+ratio3*a_temp[2*k+1];
             tempa1=2*ave_temp[k-1]-ave_temp[k-2];
             dif_temp[k]=coef*tempa1+coef0*a_temp[2*k-2]+coef1*a_temp[2*k-1]; 
             left=left-1;
           }
         }
      }
    }
    for (i=0; i<index; i++)
    { 
         dif[startstore+i]=dif_temp[i];
         sign[startstore+i]=sign_temp[i];
         
         if (j==N)
         {
           ave[i]=ave_temp[i];
         }
    }
    delete [] a_temp; 
   }
}

double minbar(double temp1, double temp2, double temp3)

{
    if ( (fabs(temp1)<=fabs(temp2)) && (fabs(temp1)<=fabs(temp3)) )
       return temp1;
    if ( (fabs(temp2)<fabs(temp3)) && (fabs(temp2)<fabs(temp1)) )
       return temp2;
    if ( (fabs(temp3)<fabs(temp2)) && (fabs(temp3)<fabs(temp1)) )
       return temp3; 
}

double minbar(double temp1, double temp2)

{
    if ( (fabs(temp1) > alpha*fabs(temp2)) && (fabs(temp1)>epsilon) ) 
       return temp2;
    else
       return temp1;
}

double gauss_generator(double mean, double variance)
{
 float u1, u2, w;

  w=1.5;
  while(w>1.0 || w==0.0)
  {
     u1=rand()*2.0/RAND_MAX-1.0;
     u2=rand()*2.0/RAND_MAX-1.0;
     w=u1*u1+u2*u2;
                        }

     u1=mean+sqrt(-2.0*log(w)/w)*u1*sqrt(variance);
  //   u2=sqrt(-2.0*log(w)/w)*u2;  N(0,1)

return u1;
}
