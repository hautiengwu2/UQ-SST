#include <iostream.h>
#include <math.h>
#include <stdlib.h>

double gauss_generator(double mean, double variance)
{
  float u1, u2, w;

  w=1.5;
  while(w>1.0 || w==0.0)
  {
     u1=rand()*2.0/RAND_MAX-1.0;
     u2=rand()*2.0/RAND_MAX-1.0;
     w=u1*u1+u2*u2;
                        }
 
     u1=mean+sqrt(-2.0*log(w)/w)*u1*sqrt(variance);
  //   u2=sqrt(-2.0*log(w)/w)*u2;  N(0,1) 

return u1;
}




