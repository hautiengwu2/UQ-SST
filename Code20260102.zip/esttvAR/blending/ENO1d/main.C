#include <iostream.h>
#include <fstream.h>
#include <math.h>
#include <stdlib.h>
#include "avedif.h"
#include "reverse.h"

//const int alpha=2;
//const double pi=3.1415926;
//const int n=512;
//const int N=5;
//const int l=16;
//const int h=496;
//const int tl=4;
 
int main()
{
   main_avedif();
   main_reverse();
   
   return 0;
}
