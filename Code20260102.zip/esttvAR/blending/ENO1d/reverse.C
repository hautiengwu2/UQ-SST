#include <iostream.h>
#include <fstream.h>
#include <math.h>
#include <stdlib.h>
#include "reverse.h"

int main_reverse()
{
   int i, j;

   int h=0,l=n;
     
   for (j=1; j<=N; j++)
   {
     if (l%2==0)
       l=l/2+1;
     else
       l=(l+1)/2+1;
     
     //cout << l << " " ;
     h=h+l;
   }

   cout.precision(14);  
   //cout << endl;
 
   intptr sign;
   double a[n];
   doubleptr ave, dif;
 
   sign=new int[h];
   ave=new double[l];
   dif=new double[h];
 
   ifstream signins;
   signins.open("sign.dat");
   if (signins.fail())
   {
     cout << "input file sign.dat opening failed. \n";
     exit(1);
   }


   ifstream aveins;
   aveins.open("average.dat");
   if (aveins.fail())
   {
     cout << "input file average.dat opening failed. \n";
     exit(1);
   }

   ifstream difins;
   difins.open("difference.dat");
   if (difins.fail())
   {
     cout << "input file difference.dat opening failed. \n";
     exit(1);
   }

   for (i=0; i<h; i++)
   {
     signins >> sign[i];
     difins >> dif[i];
     //dif[i]=0;
   }
 
   for (i=0; i<l; i++)
   {
     aveins >> ave[i];
   }
 
   ofstream reverseouts;
   reverseouts.open("reverse.dat");
   if (reverseouts.fail())
   {
     cout << "output file reverse.dat opening failed. \n";
     exit(1);
   }
   reverseouts.precision(14);

   int startindex=0, index;
   double tempd1, tempd2, tempa1, tempa2;

   for (j=N; j>=1; j--) 
   {
    index=n;
    
    for (i=1; i<=j; i++)
    { 
     if (index%2==0)
       index=index/2+1; 
     else
       index=(index+1)/2+1;
    }
 
    intptr sign_temp;
    doubleptr ave_temp, dif_temp, a_temp;   
    
    sign_temp=new int[index];
    ave_temp=new double[index];
    dif_temp=new double[index];

    if (j==N)
    a_temp=new double[2*(index-1)];
  
    //cout << index << " " << startindex << endl;
 
    for (i=0; i<index; i++)
    { 
       if (j==N)
        ave_temp[i]=ave[i];
       else
        ave_temp[i]=a_temp[i];
   
       sign_temp[i]=sign[startindex+i];

       if (j<=N-tl)
        dif_temp[i]=0;
       else
        dif_temp[i]=dif[startindex+i];
    }

     if (j!=N)
      delete [] a_temp;
     
     a_temp=new double[2*(index-1)];
  
    int left=0, k;

    for (i=1; i<index; i++)
    {
     if ((sign_temp[i]==1) && (sign_temp[i-1]==0) && (sign_temp[i+1]==0))
     {
        tempa1=2*ave_temp[i-1]-ave_temp[i-2];
        a_temp[2*i-2]=lor[1]*ave_temp[i-1]+lor[3]*tempa1
                    +hir[1]*dif_temp[i-1]+hir[3]*dif_temp[i];
        a_temp[2*i-1]=lor[0]*ave_temp[i-1]+lor[2]*tempa1
                    +hir[0]*dif_temp[i-1]+hir[2]*dif_temp[i];

        tempd1=0;
        a_temp[2*i]=lor[1]*ave_temp[i]+lor[3]*ave_temp[i+1]
                    +hir[1]*tempd1+hir[3]*dif_temp[i+1];
        a_temp[2*i+1]=lor[0]*ave_temp[i]+lor[2]*ave_temp[i+1]
                    +hir[0]*tempd1+hir[2]*dif_temp[i+1];
        i=i+1;
     }
     else if ((sign_temp[i]==1) && (sign_temp[i-1]==0) && (sign_temp[i+1]==1))
     {
        tempa1=2*ave_temp[i-1]-ave_temp[i-2];
        tempa2=2*tempa1-ave_temp[i-1];
        a_temp[2*i-2]=lor[1]*ave_temp[i-1]+lor[3]*tempa1
                    +hir[1]*dif_temp[i-1]+hir[3]*dif_temp[i];
        a_temp[2*i-1]=lor[0]*ave_temp[i-1]+lor[2]*tempa1
                    +hir[0]*dif_temp[i-1]+hir[2]*dif_temp[i];
        a_temp[2*i]=lor[1]*tempa1+lor[3]*tempa2
                    +hir[1]*dif_temp[i]+hir[3]*dif_temp[i+1];
        tempd1=0;
        tempd2=0; 
        a_temp[2*i+1]=lor[0]*ave_temp[i]+lor[2]*ave_temp[i+1]
                    +hir[0]*tempd1+hir[2]*tempd2;
        a_temp[2*i+2]=lor[1]*ave_temp[i+1]+lor[3]*ave_temp[i+2]
                    +hir[1]*tempd2+hir[3]*dif_temp[i+2];
        a_temp[2*i+3]=lor[0]*ave_temp[i+1]+lor[2]*ave_temp[i+2]
                    +hir[0]*tempd2+hir[2]*dif_temp[i+2];
        i=i+2;
     }
     else 
     {
        a_temp[2*i-2]=lor[1]*ave_temp[i-1]+lor[3]*ave_temp[i]
                    +hir[1]*dif_temp[i-1]+hir[3]*dif_temp[i];
        a_temp[2*i-1]=lor[0]*ave_temp[i-1]+lor[2]*ave_temp[i]
                    +hir[0]*dif_temp[i-1]+hir[2]*dif_temp[i];
        
     }
    }
    if (j==1)
    {
     for (i=1;i<index;i++)
     {
       a[2*i-2]=a_temp[2*i-2];
       a[2*i-1]=a_temp[2*i-1];
       reverseouts << a[2*i-2] << " " << a[2*i-1] <<" ";
     }
    } 
    //cout << endl;
    
    startindex=startindex+index;
   
    delete [] sign_temp;
    delete [] ave_temp;
    delete [] dif_temp;

   }
    
   //cout << endl; 
    signins.close();
    aveins.close();
    difins.close();
    reverseouts.close();
    //tempout.close();
   
    return 0;

} 
    


