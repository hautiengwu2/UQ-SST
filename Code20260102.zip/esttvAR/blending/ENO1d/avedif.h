#include <fstream.h>
#include <iostream.h>
#include <math.h>
#include <stdlib.h>

#ifndef avedif_H
#define avedif_H

 
const int alpha=2;
const double epsilon=0.0001;
const double pi=3.1415926;
const int n=8192;
const int N=1;
const int tl=0;
const int fillen=4;
const int turn=0;
const int tense=0;

const double lod[fillen]={-0.12940952255092, 0.22414386804186,
                          0.83651630373747, 0.48296291314469};
const double hid[fillen]={-0.48296291314469, 0.83651630373747,  
                          -0.22414386804186,-0.12940952255092};  

typedef int* intptr;
typedef double* doubleptr;
 
void init_signal(double* a, int n);
 
void ave_dif(double* a, int n, double* ave,
            int l, double* dif, int h, int* sign, int N);

double gauss_generator(double mean, double variance);
 
double minbar(double temp1, double temp2, double temp3);
double minbar(double temp1, double temp2);

int main_avedif(void);

#endif
