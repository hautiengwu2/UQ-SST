#include <iostream.h>
#include <fstream.h>
#include <math.h>
#include <stdlib.h>
#include <iomanip.h>

#include "avedif.h"
#include "reverse.h"

void main_init(double** a, int n);

int main()
{  
   int h, l, c;
   int i,j;
 
   l=n;
   h=0;
   for (j=1; j<=N; j++)
   {
     if (l%2==0)
       l=l/2+1;
     else
       l=(l+1)/2+1;
     h=h+l;
   }

   c=h+l;
   cout << l << " "  << h << " " << c << endl;
 
   
   int** signrow;
   int** signcol; 
   double** a;
   double** ainverse;
   double** enowave;

   signrow=new int*[c];
   signcol=new int*[c];
   a=new double*[n];
   ainverse=new double*[n];
   enowave=new double*[c];

   for (i=0; i<c; i++)
   {
    signrow[i]=new int[c];
    signcol[i]=new int[c];
    enowave[i]=new double[c];
   }

   for (i=0; i<n; i++)
   {
    a[i]=new double[n];
    ainverse[i]=new double[n];
   }

   main_init(a,n);
   // input the 2-dimensional initial data;

   main_avedif(a,n,enowave,signrow,signcol,c,N);
   // compute the 2-dimensional eno-wavelet transformation;

   main_reverse(ainverse,n,enowave,signrow,signcol,c,N);
   // inverse transformation;
   
   return 0;
}

void main_init(double** a, int n)
{
   int i,j;


   ifstream initins;
   initins.open("initial.dat");
   if (initins.fail())
   {
     cout << "input file initial.dat opening failed. \n";
     exit(1);
   }
    
   for (i=0; i<n; i++)
   {
      for (j=0; j<n; j++)
      {
         initins >> a[i][j];
         //a[i][j]=a[i][j]-1;
      } 
      char blank;
      initins.get(blank);
   }
   
   initins.close();

/*
   ofstream initins;
   initins.open("initial.dat");
   if (initins.fail())
   {
     cout << "input file initial.dat opening failed. \n";
     exit(1);
   }

  double step=1.0/(n/2.0-1);
  //cout << step << endl;

  for (i=0; i<n; i++)
   {
     for (j=0; j<n; j++)
     {
       //if ( fabs((i-15)*step) < (4.0/12) && fabs((j-15)*step) < (4.0/12) )
       if (sqrt(pow((i-255)*step,2)+pow((j-255)*step,2)) < (4.0/12) ) 
          a[i][j]=255;
       else 
          a[i][j]=0;
       initins <<  a[i][j] << " " ;
          
       //a[i][j]=a[i][j]-1;
     } 
     initins << endl;
   } 
   initins.close();
*/
}

