#include <iostream.h>
#include <fstream.h>
#include <math.h>
#include <stdlib.h>
#include <iomanip.h>

#include "reverse.h"

int main_reverse(double** ainverse, int n, double** enowave, 
                 int** signrow, int** signcol, int c, int N)
{  
   int i, j, k;

   int l=n;
   int h=0;
   int cut=0;
   for (j=1; j<=N; j++)
   {
     if (l%2==0)
       l=l/2+1;
     else
       l=(l+1)/2+1;
     h=h+l;
     
     if (j<=N-tl)
       cut=h;
   }

   cut = c-cut;
 
   cout << cut << endl;
   ofstream inverseout;
   inverseout.open("ainverse.dat");
   if (inverseout.fail())
   {
      cout << " output file ainverse.dat opening failed. \n";
      exit(1);
   }
     
   double** enotruncate;
 
   enotruncate=new double*[c];

   for (i=0; i<c; i++)
     enotruncate[i]=new double[c];
   
   int count=0;
   
   if  (hard!=0){
   for (i=0; i<c; i++) {
      for (j=0; j<c; j++) {
        if ((i<cut) && (j<cut)) 
          enotruncate[i][j]=enowave[i][j];
        else
          enotruncate[i][j]=0;
   } }
   } else {
       for (i=0; i<c; i++) {
         for (j=0; j<c; j++) {
          if (fabs(enowave[i][j])>=tolerance) {
           enotruncate[i][j]=enowave[i][j];
           ++count;
          }else{
           enotruncate[i][j]=0;
          }
      }}
      cout << " keep " << count << " non-zero coefficients " << endl;
   }

   for (i=0; i<n; i++)
   {
      for (j=0; j<n; j++)
      {  
        if ((i<l) && (j<l))
           ainverse[i][j]=enotruncate[i][j];
        else
           ainverse[i][j]=0;
      }
   }

   for (k=N; k>=1; k--)
   { 
     
     int startstore=0;
     int m=n;
     for (j=1; j<=k; j++)
     {
       if (m%2==0)
         m=m/2+1;
       else
         m=(m+1)/2+1;
       startstore=startstore+m;
     }
     
     m=m+m;
     startstore=c-startstore;
 
     double** aoneinverse;
     int** onesignrow;
     int** onesigncol;

     aoneinverse=new double*[m];
     onesignrow=new int*[m];
     onesigncol=new int*[m];
     for (i=0; i<m; i++)
     {
       aoneinverse[i]=new double[m];
       onesignrow[i]=new int[m];
       onesigncol[i]=new int[m];
     }

     for (i=0; i<m/2; i++)
     {
      for (j=0; j<m/2; j++)
      {
       aoneinverse[i][j]=ainverse[i][j];
       onesignrow[i][j]=0;
       onesigncol[i][j]=0;
      }
     }

     for (i=0; i<m/2; i++)
     { 
        for (j=m/2; j<m; j++)
        {
          aoneinverse[i][j]=enotruncate[i][j-m/2+startstore];
          onesignrow[i][j]=signrow[i][j-m/2+startstore];
          onesigncol[i][j]=signcol[i][j-m/2+startstore];
        }
     }

     for (i=m/2; i<m; i++)
     {
        for (j=0; j<m/2; j++)
        {
          aoneinverse[i][j]=enotruncate[i-m/2+startstore][j];
          onesignrow[i][j]=signrow[i-m/2+startstore][j];
          onesigncol[i][j]=signcol[i-m/2+startstore][j];
        }
     }

     for (i=m/2; i<m; i++)
     {  
        for (j=m/2; j<m; j++)
        {
          aoneinverse[i][j]=enotruncate[i-m/2+startstore][j-m/2+startstore];
          onesignrow[i][j]=signrow[i-m/2+startstore][j-m/2+startstore];
          onesigncol[i][j]=signcol[i-m/2+startstore][j-m/2+startstore];
        }
     }

    onelevelinverse(aoneinverse, m, onesignrow, onesigncol);
   
    for (i=0; i<m-2; i++)
    {
      for (j=0; j<m-2; j++)
       ainverse[i][j]=aoneinverse[i][j];
    }

    for (i=0; i<m; i++)
    {
     delete [] aoneinverse[i];
     delete [] onesignrow[i];
     delete [] onesigncol[i];
    }
 
    delete [] aoneinverse;
    delete [] onesignrow;
    delete [] onesigncol;
   } 
  
   for (i=0; i<n; i++)
   {
      for (j=0; j<n; j++)
      {
        //cout << setw(3) << ainverse[i][j] << " ";
        inverseout << ainverse[i][j] << " ";
      }
      inverseout << endl; 
      //cout << endl; 
   }
 
   return 0;
}

void onelevelinverse(double** aoneinverse, int m, int** onesignrow, 
                     int** onesigncol)
{ 
   int i, j;
   
   // Begin to inverse column-wise;
 
   for (i=0; i<m; i++)
   {
     doubleptr a_temp, ave_temp, dif_temp;
     intptr sign_temp;
 
     a_temp=new double[m];
     ave_temp=new double[m/2];
     dif_temp=new double[m/2];
     sign_temp=new int[m/2];
 
     for (j=0; j<m/2; j++)
     {
       ave_temp[j]=aoneinverse[j][i];
       dif_temp[j]=aoneinverse[m/2+j][i];
       sign_temp[j]=onesigncol[m/2+j][i];
     }

     oned_reverse(a_temp,m,ave_temp,dif_temp,sign_temp);

     for (j=0; j<m; j++)
       aoneinverse[j][i]=a_temp[j];
 
     delete [] a_temp;
     delete [] ave_temp;
     delete [] dif_temp;
     delete [] sign_temp;
   }

   // Begin the inverse process row-wise,
 
   for (i=0; i<m; i++)
   {
     doubleptr a_temp, ave_temp, dif_temp;
     intptr sign_temp;
 
     a_temp=new double[m];
     ave_temp=new double[m/2];
     dif_temp=new double[m/2];
     sign_temp=new int[m/2];
 
     for (j=0; j<m/2; j++)
     {
       ave_temp[j]=aoneinverse[i][j];
       dif_temp[j]=aoneinverse[i][m/2+j];
       if (i<m/2-1) 
         sign_temp[j]=onesignrow[i][m/2+j];
       else if ((i>=m/2-1) && (i<m-2))
         sign_temp[j]=onesignrow[i+1][m/2+j];
       else 
         sign_temp[j]=0;
     }
 
     oned_reverse(a_temp,m,ave_temp,dif_temp,sign_temp);
 
     for (j=0; j<m; j++)
     {
       aoneinverse[i][j]=a_temp[j];
     }

     delete [] a_temp;
     delete [] ave_temp;
     delete [] dif_temp;
     delete [] sign_temp;
   }
}

int oned_reverse(double* aoned, int noned, double* ave, double* dif,
                 int* sign)
{
   int i;
   double tempd1, tempd2, tempa1, tempa2;

   int left=0, k;

   int index=noned/2; 
   for (i=1; i<index; i++)
   {
     if ((sign[i]==1) && (sign[i-1]==0) && (sign[i+1]==0))
     {
        tempa1=2*ave[i-1]-ave[i-2];
        aoned[2*i-2]=lor[1]*ave[i-1]+lor[3]*tempa1
                    +hir[1]*dif[i-1]+hir[3]*dif[i];
        aoned[2*i-1]=lor[0]*ave[i-1]+lor[2]*tempa1
                    +hir[0]*dif[i-1]+hir[2]*dif[i];
 
        tempd1=0;
        aoned[2*i]=lor[1]*ave[i]+lor[3]*ave[i+1]
                    +hir[1]*tempd1+hir[3]*dif[i+1];
        aoned[2*i+1]=lor[0]*ave[i]+lor[2]*ave[i+1]
                    +hir[0]*tempd1+hir[2]*dif[i+1];
        i=i+1;
     }
     else if ((sign[i]==1) && (sign[i-1]==0) && (sign[i+1]==1))
     {
        tempa1=2*ave[i-1]-ave[i-2];
        tempa2=2*tempa1-ave[i-1];
        aoned[2*i-2]=lor[1]*ave[i-1]+lor[3]*tempa1
                    +hir[1]*dif[i-1]+hir[3]*dif[i];
        aoned[2*i-1]=lor[0]*ave[i-1]+lor[2]*tempa1
                    +hir[0]*dif[i-1]+hir[2]*dif[i];
        aoned[2*i]=lor[1]*tempa1+lor[3]*tempa2
                    +hir[1]*dif[i]+hir[3]*dif[i+1];
        tempd1=0;
        tempd2=0;
        aoned[2*i+1]=lor[0]*ave[i]+lor[2]*ave[i+1]
                    +hir[0]*tempd1+hir[2]*tempd2;
        aoned[2*i+2]=lor[1]*ave[i+1]+lor[3]*ave[i+2]
                    +hir[1]*tempd2+hir[3]*dif[i+2];
        aoned[2*i+3]=lor[0]*ave[i+1]+lor[2]*ave[i+2]
                    +hir[0]*tempd2+hir[2]*dif[i+2];
        i=i+2;
     }
     else
     {
        aoned[2*i-2]=lor[1]*ave[i-1]+lor[3]*ave[i]
                    +hir[1]*dif[i-1]+hir[3]*dif[i];
        aoned[2*i-1]=lor[0]*ave[i-1]+lor[2]*ave[i]
                    +hir[0]*dif[i-1]+hir[2]*dif[i];
 
     }
   }
   //aoned[2*index-2]=0;
   //aoned[2*index-1]=0;
   return 0;

} 
    


