#include <fstream.h>
#include <iostream.h>
#include <math.h>
#include <stdlib.h>

#ifndef avedif_H
#define avedif_H

const int alpha=2;
const double epsilon=30;
const double pi=3.1415926;
const int n=512;
const int N=3;
const int tl=0;
const int fillen=4;
const int hard=1;
int turn=0;
const double tolerance=510;
const double phi=10;
const double lod[fillen]={-0.12940952255092, 0.22414386804186,
                          0.83651630373747, 0.48296291314469};
const double hid[fillen]={-0.48296291314469, 0.83651630373747,
                          -0.22414386804186,-0.12940952255092};
 


typedef int* intptr;
typedef double* doubleptr;
 
void main_avedif(double** a, int n, double** enowave, 
                 int** signrow, int** signcolumn, int c, int N);

void oneleveltwod(double** aonelevel, int m, double** enowave, int** signrow,
                  int** signcolumn, int c, int startstore);
 
void ave_dif(double* aoned, int noned, double* ave,
            double* dif, int* sign);

void ave_dif_image(double* aoned, int noned, double* ave,
            double* dif, int* sign);

//void thresholding(double **enowave, int c);

//double findthresh(double **enowave, int c, int cut);

double gauss_generator(double mean, double variance);
 
double minbar(double temp1, double temp2, double temp3);
double minbar(double temp1, double temp2);

double minimum(double *a, int k, int& m);
 
#endif
