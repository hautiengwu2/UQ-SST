#include <iostream.h>
#include <fstream.h>
#include <math.h>
#include <stdlib.h>
#include "avedif.h"

#ifndef reverse_H
#define reverse_H

const double lor[fillen]={0.48296291314469,  0.83651630373747,
                          0.22414386804186, -0.12940952255092};
const double hir[fillen]={-0.12940952255092,-0.22414386804186,
                           0.83651630373747,-0.48296291314469};
 
int main_reverse(double** ainverse, int n, double** enowave,  
                 int** signrow, int** signcol, int c, int N);

void  onelevelinverse(double** aoneinverse, int m, int** signrow, 
                      int** signcol);

int oned_reverse(double* aoned, int noned, double* ave, double* dif, 
                 int* sign);
#endif
