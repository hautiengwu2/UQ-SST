#include <fstream.h>
#include <iostream.h>
#include <math.h>
#include <stdlib.h>
#include <iomanip.h>

#include "avedif.h"

void main_avedif(double** a, int n, double** enowave, 
                int** signrow, int** signcolumn, int c, int N)
{
   int i,j, k;
   
   int l,h; 
   l=n;
   h=0;
   for (j=1; j<=N; j++)
   {
     if (l%2==0)
       l=l/2+1;
     else
       l=(l+1)/2+1;
     h=h+l;
   }

   // initialize signrow and signcolumn;
   for (i=0; i<c; i++)
   {
     for (j=0; j<c; j++)
     {
        signrow[i][j]=0;
        signcolumn[i][j]=0;
        enowave[i][j]=0;
     }
   } 

   ofstream enoouts;
   enoouts.open("enowave.dat");
   if (enoouts.fail())
   {
     cout << "output file enowave.dat opening failed. \n";
     exit(1);
   }

   ofstream signrowouts;
   signrowouts.open("signrow.dat");
   if (signrowouts.fail())
   {
     cout << "output file signrow.dat opening failed. \n";
     exit(1);
   }
 
   ofstream signcolouts;
   signcolouts.open("signcol.dat");
   if (signcolouts.fail())
   {
     cout << "output file signcol.dat opening failed. \n";
     exit(1);
   }

   int startstore=c;
   int index=n;
   int index_old=index;
 
   for (k=1; k<=N; k++)
   { 
       
       index_old=index;
 
       if (index%2==0)
          index=index/2+1;
       else
          index=(index+1)/2+1;

       double** aonelevel;
       
       int m;

       if (index_old%2==0)
       {
          aonelevel=new double*[index_old];
          for (i=0; i<index_old; i++)
          {
              aonelevel[i]=new double[index_old];
          }

          for (i=0; i<index_old; i++)
          {
              for (j=0; j<index_old; j++)
              {
                if (k==1)
                  aonelevel[i][j]=a[i][j];
                if (k>1)
                  aonelevel[i][j]=enowave[i][j];
              }
          }
          m=index_old;
       }
       else
       {
          aonelevel=new double*[index_old+1];
          for (i=0; i<index_old+1; i++)
          {
              aonelevel[i]=new double[index_old+1];
          }

          for (i=0; i<index_old+1; i++)
          {
              for (j=0; j<index_old+1; j++)
                 aonelevel[i][j]=0;
          }
 
          for (i=0; i<index_old; i++)
          {
              for (j=0; j<index_old; j++)
              {
                if (k==1)
                  aonelevel[i][j]=a[i][j];
                if (k>1)
                  aonelevel[i][j]=enowave[i][j];
              }
          }
          m=index_old+1;
       }
   
       startstore=startstore-index; 

       cout << " level is : " << k << " ******************* " << endl;
 
       oneleveltwod(aonelevel,m,enowave,signrow,signcolumn,c,startstore);
       index_old=index;
       for (i=0; i<m; i++) 
         delete [] aonelevel[i];
   
       delete [] aonelevel;
   }

   //thresholding(enowave,c); 
   //begin to output the tranformation coefficents.
 
    for (i=0; i<c; i++)
    {
      for (j=0; j<c; j++)
      {
        enoouts << enowave[i][j] << " ";
 
        signrowouts << signrow[i][j] << " ";
        signcolouts << signcolumn[i][j] << " ";
        //cout << signrow[i][j] << " ";
        //cout << signcolumn[i][j] << " ";
      }
      enoouts << endl;
      signrowouts << endl;
      signcolouts << endl;
    }
 
   enoouts.close();
   signrowouts.close();
   signcolouts.close();
 
}

void oneleveltwod(double** aonelevel, int m, double** enowave, int** signrow,
                  int** signcolumn, int c, int startstore)
{ 
   int i, j;
    
   // Begin to transform row by row;
   for (i=0; i<m/2; i++)
   {
     doubleptr temp, avetemp, diftemp;
     intptr signrowtemp;
 
     temp=new double[m];
     avetemp=new double[m/2+1];
     diftemp=new double[m/2+1];
     signrowtemp=new int[m/2+1];
 
     for (j=0; j<m; j++)
     {
       temp[j]=aonelevel[i][j];
     } 
     cout << " row is " << i << " ################ " << endl;

     //ave_dif(temp,m,avetemp,diftemp,signrowtemp);
     ave_dif_image(temp,m,avetemp,diftemp,signrowtemp);
 
     for (j=0; j<m/2+1; j++)
     {
       enowave[i][j]=avetemp[j];
       enowave[i][startstore+j]=diftemp[j];
       signrow[i][startstore+j]=signrowtemp[j];
     }
 
     delete [] temp;
     delete [] avetemp;
 
     delete [] diftemp;
     delete [] signrowtemp;

    }

   for (i=0; i<m/2; i++)
   {
     doubleptr temp, avetemp, diftemp;
     intptr signrowtemp;
 
     temp=new double[m];
     avetemp=new double[m/2+1];
     diftemp=new double[m/2+1];
     signrowtemp=new int[m/2+1];
 
     for (j=0; j<m; j++)
     {
       temp[j]=aonelevel[i+m/2][j];
     }

     cout << " row is " << i << " ################ " << endl;

     //ave_dif(temp,m,avetemp,diftemp,signrowtemp);
     ave_dif_image(temp,m,avetemp,diftemp,signrowtemp); 
     for (j=0; j<m/2+1; j++)
     {
       enowave[i+m/2][j]=avetemp[j];
       enowave[i+m/2][startstore+j]=diftemp[j];
       signrow[i+startstore][startstore+j]=signrowtemp[j];
     }
 
     delete [] temp;
     delete [] avetemp;
 
     delete [] diftemp;
     delete [] signrowtemp;
 
   }

    //Begin to transform column by column;
 
   for (i=0; i<m/2+1; i++)
   {
     doubleptr temp, avetemp, diftemp;
     intptr signcoltemp;
 
     temp=new double[m];
     avetemp=new double[m/2+1];
     diftemp=new double[m/2+1];
     signcoltemp=new int[m/2+1];
 
     for (j=0; j<m; j++)
       temp[j]=enowave[j][i];

     cout << " column is " << i << " ################ " << endl;

     //ave_dif(temp,m,avetemp,diftemp,signcoltemp);
     ave_dif_image(temp,m,avetemp,diftemp,signcoltemp);
     for (j=0; j<m/2+1; j++)
     {
       enowave[j][i]=avetemp[j];
       enowave[j+startstore][i]=diftemp[j];
       signcolumn[j+startstore][i]=signcoltemp[j];
     }
 
     delete [] temp;
     delete [] avetemp;
     delete [] diftemp;
     delete [] signcoltemp;

    }
   for (i=0; i<m/2+1; i++)
   {
     doubleptr temp, avetemp, diftemp;
     intptr signcoltemp;
 
     temp=new double[m];
     avetemp=new double[m/2+1];
     diftemp=new double[m/2+1];
     signcoltemp=new int[m/2+1];
 
     for (j=0; j<m; j++)
       temp[j]=enowave[j][startstore+i];

     cout << " column is " << i << " ################ " << endl;

     //ave_dif(temp,m,avetemp,diftemp,signcoltemp);
     ave_dif_image(temp,m,avetemp,diftemp,signcoltemp);

     for (j=0; j<m/2+1; j++)
     {
       enowave[j][i+startstore]=avetemp[j];
       enowave[j+startstore][i+startstore]=diftemp[j];
       signcolumn[j+startstore][i+startstore]=signcoltemp[j];
     }
 
     delete [] temp;
     delete [] avetemp;
     delete [] diftemp;
     delete [] signcoltemp;
 
    }

}

void ave_dif(double* aoned, int noned, double* ave, 
             double* dif, int* sign)
{
   int i;
   int left=0, k;
   double tempdif1=0, tempdif2=1, tempdif3=1;
   double tempa1=0, tempd1=0, tempa2=0, tempd2=0;
   double tempx1=0, tempx2=0;
 
   double coef, coef0, coef1, coef2, coef3;
   double ratio, ratio2, ratio3;
 
   ratio=lod[0]/hid[0];
   ratio2=lod[2]-ratio*hid[2];
   ratio3=lod[3]-ratio*hid[3];
 
   coef=hid[3]/lod[3];
   coef0=hid[0]-coef*lod[0];
   coef1=hid[1]-coef*lod[1];
   coef2=hid[2]-coef*lod[2];
   coef3=hid[3]-coef*lod[3];
 
   int index=noned/2+1;
    
    for (i=0; i<index; i++)
    {
      sign[i]=0;
      int l_temp=index-1;
      if (i==l_temp)
      {
         ave[i]=(lod[0]*aoned[2*i-2]+lod[1]*aoned[2*i-1]);
         dif[i]=(hid[0]*aoned[2*i-2]+hid[1]*aoned[2*i-1]);
         //cout <<dif[i-2] << " " << dif[i-1] << " " << dif[i] << endl;
      }
      else if (i==0)
      {
         ave[i]=(lod[2]*aoned[2*i]+lod[3]*aoned[2*i+1]);
         dif[i]=(hid[2]*aoned[2*i]+hid[3]*aoned[2*i+1]);
      }
      else if (i<=2)
      {
         ave[i]=(lod[0]*aoned[2*i-2]+lod[1]*aoned[2*i-1]
                      +lod[2]*aoned[2*i]+lod[3]*aoned[2*i+1]);
         dif[i]=(hid[0]*aoned[2*i-2]+hid[1]*aoned[2*i-1]
                      +hid[2]*aoned[2*i]+hid[3]*aoned[2*i+1]);
      }
      else
      {
         ave[i]=(lod[0]*aoned[2*i-2]+lod[1]*aoned[2*i-1]+
                      lod[2]*aoned[2*i] + lod[3]*aoned[2*i+1]);
         dif[i]=(hid[0]*aoned[2*i-2]+hid[1]*aoned[2*i-1]+
                   hid[2]*aoned[2*i]+hid[3]*aoned[2*i+1]);

         
         tempdif2=(hid[0]*aoned[2*i-2]+hid[1]*aoned[2*i-3]+
                   hid[2]*aoned[2*i-4]+hid[3]*aoned[2*i-5]);
       
         if ( (fabs(dif[i])>alpha*fabs(tempdif2))
             && ( fabs(dif[i])>epsilon) )
         {
           sign[i]=1;
           k=i-1;
           if (sign[k]==0)
             left=left+1;
           else
           {
            while (left>0)
            {
              tempa1=2*ave[k-1]-ave[k-2];
              dif[k]=coef*tempa1+coef0*aoned[2*k-2]+coef1*aoned[2*k-1];
              tempx1=(tempa1-(lod[0]*aoned[2*k-2]+lod[1]*aoned[2*k-1]
                             +lod[2]*aoned[2*k]))/lod[3];
              tempa2=2*tempa1-ave[k-1];
              dif[i]=coef*tempa2+coef0*aoned[2*k]+coef1*tempx1;
              tempx2=-(hid[1]*aoned[2*k+1]+hid[2]*aoned[2*k+2]
                       +hid[3]*aoned[2*k+3])/hid[0];
              ave[i]=lod[0]*tempx2+lod[1]*aoned[2*k+1]
                          +lod[2]*aoned[2*k+2]+lod[3]*aoned[2*k+3];
              ave[k]=ratio2*tempx2+ratio3*aoned[2*k+1];
              left=left-1;
            }
           }
         }
         else
         {
           while (left>0)
           {
             k=i-1;
             ave[k]=ratio2*aoned[2*k]+ratio3*aoned[2*k+1];
             tempa1=2*ave[k-1]-ave[k-2];
             dif[k]=coef*tempa1+coef0*aoned[2*k-2]+coef1*aoned[2*k-1];
             left=left-1;
           }
         }
         
       //cout << "i " << i << " " << ave[i] << " " << dif[i] << " " << 
       //     tempdif2 << " "  << sign[i] <<   endl;
      }
      //cout << "i " << i << " " << ave[i] << " " << dif[i] << endl;
    }
}


void ave_dif_image(double* aoned, int noned, double* ave,
             double* dif, int* sign)
{
   int i;
   int left=0, k;
   double tempdif1=0, tempdif2=1, tempdif3=1;
   double tempa1=0, tempd1=0, tempa2=0, tempd2=0;
   double tempx1=0, tempx2=0;
 
   double coef, coef0, coef1, coef2, coef3;
   double ratio, ratio2, ratio3;
 
   ratio=lod[0]/hid[0];
   ratio2=lod[2]-ratio*hid[2];
   ratio3=lod[3]-ratio*hid[3];
 
   coef=hid[3]/lod[3];
   coef0=hid[0]-coef*lod[0];
   coef1=hid[1]-coef*lod[1];
   coef2=hid[2]-coef*lod[2];
   coef3=hid[3]-coef*lod[3];
 
   int index=noned/2+1;
 
    for (i=0; i<index; i++)
    {
      sign[i]=0;
      int l_temp=index-1;
      if (i==l_temp)
      {
         ave[i]=(lod[0]*aoned[2*i-2]+lod[1]*aoned[2*i-1]);
         dif[i]=(hid[0]*aoned[2*i-2]+hid[1]*aoned[2*i-1]);
         //cout <<dif[i-2] << " " << dif[i-1] << " " << dif[i] << endl;
      }
      else if (i==0)
      {
         ave[i]=(lod[2]*aoned[2*i]+lod[3]*aoned[2*i+1]);
         dif[i]=(hid[2]*aoned[2*i]+hid[3]*aoned[2*i+1]);
      }
      else if (i<=2)
      {
         ave[i]=(lod[0]*aoned[2*i-2]+lod[1]*aoned[2*i-1]
                      +lod[2]*aoned[2*i]+lod[3]*aoned[2*i+1]);
         dif[i]=(hid[0]*aoned[2*i-2]+hid[1]*aoned[2*i-1]
                      +hid[2]*aoned[2*i]+hid[3]*aoned[2*i+1]);
      }
      else if (i>=l_temp-2)
      {
         ave[i]=(lod[0]*aoned[2*i-2]+lod[1]*aoned[2*i-1]
                      +lod[2]*aoned[2*i]+lod[3]*aoned[2*i+1]);
         dif[i]=(hid[0]*aoned[2*i-2]+hid[1]*aoned[2*i-1]
                      +hid[2]*aoned[2*i]+hid[3]*aoned[2*i+1]);
      }
      else
      {
         ave[i]=(lod[0]*aoned[2*i-2]+lod[1]*aoned[2*i-1]+
                      lod[2]*aoned[2*i] + lod[3]*aoned[2*i+1]);
         dif[i]=(hid[0]*aoned[2*i-2]+hid[1]*aoned[2*i-1]+
                   hid[2]*aoned[2*i]+hid[3]*aoned[2*i+1]);

 
         //if (sign[i-2]==0)
         //{
 
         //tempdif2=(hid[0]*aoned[2*i-2]+hid[1]*aoned[2*i-3]+
         //          hid[2]*aoned[2*i-4]+hid[3]*aoned[2*i-5]);
         tempdif2=dif[i-1]; 
           
         //if (fabs(dif[i])>epsilon || fabs(tempdif2)>epsilon)
            //cout << " forward " << dif[i] << " backward " 
          //       << tempdif2 << endl;
 
         if ( (fabs(dif[i])>alpha*fabs(tempdif2))
             && ( fabs(dif[i])>epsilon) && turn==0 
             && sign[i-1]==0 && sign[i-2]==0)
         {
           double temp1, temp2, temp3;
           int jump;
 
           temp3=fabs(aoned[2*i+1]-aoned[2*i]);
           temp2=fabs(aoned[2*i]-aoned[2*i-1]);
           temp1=fabs(aoned[2*i-1]-aoned[2*i-2]);
 
           cout << " temp1 " << temp1 << " temp2 " << temp2 
                << " temp3 " << temp3 << endl;

           if (temp1>=temp2 && temp1 >=temp3 && temp1>phi)
               jump=1;
           
           if (temp2>=temp1 && temp2 >=temp3 && temp2>phi)
               jump=2;
          
           if (temp3>=temp1 && temp3 >=temp2 && temp3>phi)
               jump=3;
          
           if (jump==1){
              --i;
            cout << " I am here " << i << endl;
           }
           k=i;
           if (jump==1 || jump==3){
              ++i;
              sign[k]=1;
              sign[i]=1;
              cout << " sign[k-1]= " << sign[k-1] << endl;
              if (sign[k-1]==1 || sign[k-2]==1)
               tempa1=ave[k-1];
              else
               tempa1=2*ave[k-1]-ave[k-2];

              cout << " tempa1 " << tempa1;
              dif[k]=coef*tempa1+coef0*aoned[2*k-2]+coef1*aoned[2*k-1];
              tempx1=(tempa1-(lod[0]*aoned[2*k-2]+lod[1]*aoned[2*k-1]
                             +lod[2]*aoned[2*k]))/lod[3];
              cout << " tempx1 " << tempx1;
              tempa2=2*tempa1-ave[k-1];
              cout << " tempa2 " << tempa2;
              dif[i]=coef*tempa2+coef0*aoned[2*k]+coef1*tempx1;
              tempx2=-(hid[1]*aoned[2*k+1]+hid[2]*aoned[2*k+2]
                       +hid[3]*aoned[2*k+3])/hid[0];
              cout << " tempx2 " << tempx2 << endl;
              cout << aoned[2*k-4] << " " << aoned[2*k-3] << " " 
                   << aoned[2*k-2] << " " << aoned[2*k-1] << " " << aoned[2*k]
                   << " " <<  aoned[2*k+1] << " " << aoned[2*k+2] << " " <<
                   aoned[2*k+3] << " " << aoned[2*k+4] << endl;
              ave[i]=lod[0]*tempx2+lod[1]*aoned[2*k+1]
                          +lod[2]*aoned[2*k+2]+lod[3]*aoned[2*k+3];
              ave[k]=ratio2*tempx2+ratio3*aoned[2*k+1];
              cout << " i is " << i << " jump is " << jump 
                   << " average is " << ave[k] << " " 
                   << ave[i] << " dif is  "<< dif[k] << " " << dif[i] << endl;

              if (jump==1){
                 ++i;
                 ave[i]=(lod[0]*aoned[2*i-2]+lod[1]*aoned[2*i-1]+
                         lod[2]*aoned[2*i] + lod[3]*aoned[2*i+1]);
                 dif[i]=(hid[0]*aoned[2*i-2]+hid[1]*aoned[2*i-1]+
                         hid[2]*aoned[2*i]+hid[3]*aoned[2*i+1]);
                 sign[i]=0;
              }
           }
           if (jump==2){
             sign[i]=2;
             ave[i]=ratio2*aoned[2*i]+ratio3*aoned[2*i+1];
             if (sign[i-1]==0)
                tempa1=2*ave[i-1]-ave[i-2];
             else
                tempa1=ave[i-1];

             dif[i]=coef*tempa1+coef0*aoned[2*i-2]+coef1*aoned[2*i-1];
              cout << " i is " << i << " jump is " << jump 
                   << " average is " << ave[i] << " " 
                   << " dif is  " << dif[i] << endl;
           }
         }
 
      }
      //cout << "i " << i << " " << ave[i] << " " << dif[i] << endl;
    }
}


double minbar(double temp1, double temp2, double temp3)
{
    if ( (fabs(temp1)<=fabs(temp2)) && (fabs(temp1)<=fabs(temp3)) )
       return temp1;
    if ( (fabs(temp2)<fabs(temp3)) && (fabs(temp2)<fabs(temp1)) )
       return temp2;
    if ( (fabs(temp3)<fabs(temp2)) && (fabs(temp3)<fabs(temp1)) )
       return temp3; 
}

double minbar(double temp1, double temp2)
 
{
    if ( (fabs(temp1) > alpha*fabs(temp2)) && (fabs(temp1)>epsilon) )
       return temp2;
    else
       return temp1;
}

double gauss_generator(double mean, double variance)
{
 float u1, u2, w;

  w=1.5;
  while(w>1.0 || w==0.0)
  {
     u1=rand()*2.0/RAND_MAX-1.0;
     u2=rand()*2.0/RAND_MAX-1.0;
     w=u1*u1+u2*u2;
                        }

     u1=mean+sqrt(-2.0*log(w)/w)*u1*sqrt(variance);
  //   u2=sqrt(-2.0*log(w)/w)*u2;  N(0,1)

return u1;
}
/*
void thresholding(double ** enowave, int c)
{
   int i, j, k;
   double hardthresh;
 
   int l=n;
   int h=0;
   int cut=0;
   for (j=1; j<=N; j++)
   {
     if (l%2==0)
       l=l/2+1;
     else
       l=(l+1)/2+1;
     h=h+l;
 
     if (j<=tn)
       cut=h;
   }
 
   cut = c-cut;
   cut = cut*cut;
   cout << "cut=" << cut << endl;  
 
   if (p=='r')
   {
     hardthresh = findthresh(enowave, c, cut);
     cout << "hardthresh=" << hardthresh << endl;
     for (i=0; i<c; i++)
     {
        for (j=0; j<c; j++)
        {
           if (fabs(enowave[i][j])<hardthresh)
               enowave[i][j]=0;
        }
     }
 
 
   }
   else
   {
     for (i=0; i<c; i++)
     {
        for (j=0; j<c; j++)
        {
           if (fabs(enowave[i][j])<threshold)
               enowave[i][j]=0;
        }
     }
   }
}
 
double findthresh(double **enowave, int c, int cut)
{
  int i, j, m=0;
  double thresh=0;
  double *a;
  
  a=new double[cut];
 
  for (i=0; i<cut; i++)
    a[i]=0;
 
  for (i=0; i<c; i++)
  {
    for (j=0; j<c; j++)
    {
      if (fabs(enowave[i][j]) >= thresh)
      {
          a[m]=fabs(enowave[i][j]);
          thresh=minimum(a,cut,m); 
      }
    }
  }
  delete [] a;
  return thresh;
}
*/

double minimum(double *a, int k, int& m)
{
   double minvalue=a[0];
   
   int i;
   
   for (i=1; i<k; i++)
   {
     if (fabs(a[i])==0)
     {
        minvalue=0;
        m=i;
        break;
     }
     if (minvalue>fabs(a[i]))
     {
       minvalue=fabs(a[i]);
       m=i;
     }  
   }
   return minvalue;
}
