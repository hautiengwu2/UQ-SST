function [B,l] = genWaveletBasis(N, J, wname)
% N = 2^k
% J is the level of MRA, J<k

% HiD = g_j, LoD = h_j in ID's book
[LoD, HiD, LoR, HiR] = wfilters(wname) ;

B = zeros(N) ;
%psi = HiR ;
%phi = LoR ;

% the finest (first) layer basis
piv = 0 ;

for jj = 1: J
    bsize = N / 2^jj ;
    %disp(bsize)
    %psi = conv(fliplr(dyadup(phi,0)), HiR) ;
    %phi = conv(fliplr(dyadup(phi,0)), LoR) ;
    psi = upcoef('d', 1, LoR, HiR, jj, N) ;
    phi = upcoef('a', 1, LoR,'dummy', jj, N) ;
    B(piv+1, 1:length(psi)) = psi ;
    for kk = 2: bsize
        B(piv+kk, :) = circshift(B(piv+1, :), (2^jj)*(kk-1)) ;
    end

    if jj == J
        B(piv+bsize+1, 1:length(psi)) = phi ;
        for kk = 2: bsize
            B(piv+bsize+kk, :) = circshift(B(piv+bsize+1, :), (2^jj)*(kk-1)) ;
        end
    end

    % next level, decimation by 2
    piv = piv + bsize ;
    l(jj) = bsize ;
end


