function [xKP1] = genLS_KP2015(x, kappa4)
%
% This is an implementation of Bootstrapping locally stationary processes
% 2015 by Jens-Peter Kreiss and Efstathios Paparoditis
%
x = x(:) ;
n = length(x) ;


% preparation in section 4.1
ctilde0 = zeros(1, n) ;
ctilde1 = zeros(1, n) ;
T = 6 ;
[h] = hermf(T, 1, 4) ; h = h(:) ;
HT = sum(h.^2) ;

for jj = 1: n
    tmp = x(mod((jj-T/2+1:jj+T/2)-1, n)+1) ;
    ctilde0(jj) = (h.^2)' * (tmp.^2) / HT ; 
    tmpt = x(mod((jj-T/2+1:jj+T/2-1)-1, n)+1) ;
    tmps = x(mod((jj-T/2:jj+T/2-2)-1, n)+1) ;
    ctilde1(jj) = (h(1:end-1).*h(2:end))' * (tmpt.*tmps) / HT ; 
end

phihat = ctilde1 ./ ctilde0 ;
lambdalist = linspace(-pi, pi, T)' ;
ghat = 1 + ones(T,1) * phihat.^2 -  cos(lambdalist) * 2*phihat ;

Du = pi * sum( sum( (log( ghat(:, T/2+1: n-T/2) ./ ghat(:, T/2-1:n-T/2-2) )).^2, 1), 2) / T ;
Dl = pi * sum( sum( (log( ghat(3:end, T/2+1: n-T/2) ./ ghat(1:end-2, T/2+1:n-T/2) )).^2, 1), 2) / n ;


tauhat = ((576*pi/n)^(1/6)) * (Dl / Du^5)^(1/12) ; 
bhat = ((576*pi/n)^(1/6)) * (Du / Dl^5)^(1/12) ; 
N = round(tauhat * n/2) * 2 ;


% this is local periodogram
Itilde = zeros(n, n) ;

for jj = 1: n
    tmp = x(mod((jj-N/2:jj+N/2)-1, n)+1) ;
    Itilde(:, jj) = abs(fft(tmp, n)).^2 / N ;
end


% estimate tvPS of x
fhat = zeros(n, n) ;
% the spectral band is from -pi to pi
Kb = 6 * (1/4 - (linspace(-bhat, bhat, round(bhat*n/pi))./ bhat/2).^2) ;

for jj = 1: n
    fhat(:, jj) = conv(Itilde(:, jj), Kb, 'same') / length(Kb) ;
    % force symmetry. Assume n is even.
    fhat(end:-1:end/2+2, jj) = fhat(2:end/2, jj) ;
end

fhatsr = fhat.^(1/2) ;


% generate innovation
epsstar = zeros(size(x)) ;
tmp = rand(size(x)) ;
kappa4tilde = kappa4 + 3 ; 
epsstar(tmp > 1-1/kappa4tilde/2) = sqrt(kappa4tilde) ;
epsstar(tmp < 1/kappa4tilde/2) = -sqrt(kappa4tilde) ;
Jstar = fft(epsstar) ;


% generate bootstrapped noise
xKP1 = zeros(size(x)) ;

for jj = 1: length(x)
    tmp = ifft(fhatsr(:, jj) .* Jstar) ;
    xKP1(jj) = tmp(jj) ;
end