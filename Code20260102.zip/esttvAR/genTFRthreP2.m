function [bsSTFTth, bsSSTth] = genTFRthreP2(phihat, sigmai, x, downFn, downTn, PP, BSP, thre)

N = length(x) ;

bsSTFTth0 = repmat(P2(thre), downFn, downTn) ;
bsSSTth0 = repmat(P2(thre), downFn, downTn) ;


for qqq = 1: BSP.BSno

    waitbar(qqq/BSP.BSno)

    % generate "bootstrapped distribution"
    [bsnoise] = gentvAR(phihat, sigmai, x, BSP) ;

    [tfr, ~, tfrsq, tfrsqtic, ~, ~] = ConceFT_sqSTFT_C(...
        bsnoise, PP.LowFrequencyLimit, ...
        PP.HighFrequencyLimit, PP.FrequencyAxisResolution, PP.HOP, PP.WindowLength, ...
        PP.NoWindowsInConceFT, PP.WindowBandwidth, PP.NoConceFT, 0, 1) ;

    if qqq == 1
        idxf = BSP.fHOP/2: BSP.fHOP: length(tfrsqtic)-BSP.fHOP/2 ;
        idxt = 5:PP.HOP:N ;
    end

    for kk = 1: downFn
        for ll = 1: downTn
            bsSTFTth0(kk, ll).add(abs(tfr(idxf(kk), idxt(ll)))) ;
            bsSSTth0(kk, ll).add(abs(tfrsq(idxf(kk), idxt(ll)))) ;
        end
    end
end

bsSTFTth = zeros(downFn, downTn) ;
bsSSTth = zeros(downFn, downTn) ;

for kk = 1: downFn
    for ll = 1: downTn
        bsSTFTth(kk, ll) = bsSTFTth0(kk, ll).result() ;
        bsSSTth(kk, ll) = bsSSTth0(kk, ll).result() ;
    end
end