function [xP] = genLS_Poskitt2025(x)
%
% This is an implementation of BOOTSTRAPPING NON-STATIONARY AND IRREGULAR 
% TIME SERIES USING SINGULAR SPECTRAL ANALYSIS by DON S. POSKITT 2025
%
x = x(:) ;
N = length(x) ;

m = round(0.1 * N) ; % suggested above (3)
n = N-m+1 ;

X = zeros(m, n) ;
for jj = 1: n
    X(:, jj) = x(jj: jj+m-1) ;
end

S = zeros(m, 1) ;

for jj = 1: m
    S(jj) = norm(x(jj: jj+n-1)) ;
end

Y = diag(1./S) * X ;

[u,l,v] = svd(Y) ;

[ustar, ~] = qr(randn(m)) ; 

z = randn(m, 1) ;
lbar = mean(diag(l).^2 ./ abs(1 + z * sqrt(2/n))) ;
lstar = sqrt(diag(l).^2 ./ lbar ./ abs(1 + z * sqrt(2/n))) ;
lstar = sort(lstar, 'descend') ;

Lstar = zeros(m, n) ; 
Lstar(:, 1:m) = diag(lstar) ;
Ystar = ustar * Lstar * v' ;

Xstar = diag(S) * Ystar ;

xP = [Xstar(1, 1:end)'; Xstar(2: m, end)] ;